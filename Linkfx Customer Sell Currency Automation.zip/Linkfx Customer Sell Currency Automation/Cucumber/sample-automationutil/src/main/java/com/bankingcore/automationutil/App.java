package com.bankingcore.automationutil;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.FilenameUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;

/**
 * @author madusanka@codelantic.com
 *
 *         <br/>
 *         projectType--> (customer, admin, agent)
 */
public class App {

	private static final String CUSTOMER_DRIVE_PATH = "https://codelantic-automation.tk/Automation/Customer_Portal/overview-features.html";
	private static final String ADMIN_DRIVE_PATH = "https://codelantic-automation.tk/Automation/Admin_Portal/overview-features.html";
	private static final String AGENT_FRIVE_PATH = "https://codelantic-automation.tk/Automation/Agent_Portal/overview-features.html";
	
	private static final String DRIVE_URL= "driveUrl";
	private static final String PORTAL = "portal";

	public static void main(String[] args) {

		try {
			String path = getBasePath(args[0]);

			Thread.sleep(2000);

			uploadImagesToServer(args[0], path);

			Thread.sleep(5000);

			sendEmail(args[0]);

			System.exit(0);

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	/**
	 * return base project path based on project type
	 * 
	 * @param projectType
	 * @return path
	 * @throws Exception
	 */
	private static String getBasePath(String projectType) throws Exception {
		String path = "";
		File configData = new File("C:\\configData_" + projectType + ".txt");
		Scanner myReader = new Scanner(configData);
		while (myReader.hasNextLine()) {
			path = myReader.nextLine();
		}
		myReader.close();
		return path;
	}

	/**
	 * sending email using email service (need to up run on port 6002)
	 * 
	 * @param projectType
	 * @throws Exception
	 */
	private static void sendEmail(String projectType) throws Exception {

		List<String> toAddress = new ArrayList<String>();

		File configData = new File("C:\\addressList.txt");
		Scanner myReader = new Scanner(configData);
		while (myReader.hasNextLine()) {
			toAddress.add(myReader.nextLine());
		}
		myReader.close();

		LocalDateTime localDateTime = LocalDateTime.now();
		String dateTime = localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

		MessageDto messageDto = new MessageDto();
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("dateTime", dateTime);
		if (projectType.equals("Customer")) {
			data.put(DRIVE_URL, CUSTOMER_DRIVE_PATH);
			data.put(PORTAL, "Customer Portal");			
			messageDto.setSubject("Monex Money Transfer - Automation Test Summary - Customer Portal");
		} else if (projectType.equals("Agent")) {
			data.put(DRIVE_URL, AGENT_FRIVE_PATH);
			data.put(PORTAL, "Agent Portal");
			messageDto.setSubject("Monex Money Transfer - Automation Test Summary - Agent Portal");
		} else if (projectType.equals("Admin")) {
			data.put(DRIVE_URL, ADMIN_DRIVE_PATH);
			data.put(PORTAL, "Admin Portal");			
			messageDto.setSubject("Monex Money Transfer - Automation Test Summary - Admin Portal");
		}

		messageDto.setTemplateName("qa_automation_new");
		messageDto.setToAddress(toAddress);
		messageDto.setData(data);

		DefaultHttpClient httpClient = new DefaultHttpClient();

		HttpPost postRequest = new HttpPost("http://localhost:6002/v1/communication/email/template/awsmessage");

		postRequest.addHeader("content-type", "application/json");

		Gson gson = new Gson();
		StringEntity userEntity = new StringEntity(gson.toJson(messageDto, MessageDto.class));
		postRequest.setEntity(userEntity);

		HttpResponse response = httpClient.execute(postRequest);

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode != 200) {
			throw new RuntimeException("Failed with HTTP error code : " + statusCode);
		} else {
			System.out.println("Message Sent.");
		}
	}

	private static void deleteDir(File file) {
		File[] contents = file.listFiles();
		if (contents != null) {
			for (File f : contents) {
				deleteDir(f);
			}
		}
		file.delete();
	}

	/**
	 * FTP file upload
	 * 
	 * @param projectType
	 */
	private static void uploadImagesToServer(String projectType, String basePath) throws InterruptedException {
		FTPConnectionUtil ftpConnectionUtil = new FTPConnectionUtil();

		ftpConnectionUtil.openConnection();
		String path = basePath + "\\target\\reports\\html-reports\\cucumber-html-reports\\";

		File baseFolder = new File(path);
		for (File fileEntry : baseFolder.listFiles()) {
			if (FilenameUtils.getExtension(fileEntry.getPath()).equals("html")) {
				ftpConnectionUtil.uploadFile(fileEntry, projectType + "_Portal/" + fileEntry.getName());
			}
		}
		ftpConnectionUtil.closeConnection();

	}
}
