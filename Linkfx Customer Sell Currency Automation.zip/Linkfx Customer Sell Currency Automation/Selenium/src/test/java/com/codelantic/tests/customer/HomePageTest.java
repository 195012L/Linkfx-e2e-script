package com.codelantic.tests.customer;

import com.codelantic.pages.customer.HomePage;
import com.codelantic.pages.customer.LandingPage;
import com.codelantic.pages.customer.SignInPF;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class HomePageTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignInPF signInPFObj;
    private HomePage homePageObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }

            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);
            homePageObj = new HomePage(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
        driver.manage().window().maximize();
    }

    @Test(description = "customer landing page - sending money form - Sending Country input field")
    public void TC2028(){

        String sendingCountry = "United Kingdom";

        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        homePageObj.setSendingCountryIF(sendingCountry);
    }

    @Test(description = "customer landing page - sending money form - Recipient Country input field")
    public void TC2029(){

        String recipentCountry = "Thailand";

        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        homePageObj.setRecipientCountryIF(recipentCountry);
    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            driver.quit();
        }
    }


}
