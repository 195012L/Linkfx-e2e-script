package com.Linkfxs.automation.stepdefinition;

import java.util.List;

import com.Linkfx.automation.seleniumpages.AdminAddDeal;
import com.Linkfx.datatables.AddUser;
import com.Linkfx.datatables.AddDeal;
import com.Linkfx.utils.CommonOp;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;

	public class AdminAddDealProcess {
	AdminAddDeal simpleLoginpage = new AdminAddDeal();
	
	private CommonOp commonOpObj = null;
	@Given("^Redirect the admin login URL$")
	public void Redirect_the_admin_login_URL() 
	{
		simpleLoginpage.launchChromeBrowser();
		
	}
	@Given("^Redirect the admin on deal URL$")
	public void Redirect_the_admin_on_deal_URL(List<AddDeal> addDeal) throws Exception 
	{
		simpleLoginpage.AdminRedirect(addDeal);
	}
	@When("^I enter the username and password$")
	public void User_Login_Again(List<AddUser> addUser) throws Exception 
	{
		
		simpleLoginpage.loginAgain(addUser);	
	}
	
	@And("^Check back office dashboard tabs$")
	public void Check_back_office_dashboard_tabs()
	{
		simpleLoginpage.BackofficeTabs();
	}
	@When("^Click on Deal tab$")
	public void Click_on_Deal_tab()
	{
		simpleLoginpage.Dealtab();
	}
	@And("^Click on Add deal button$")
	public void Click_on_Add_deal_button()
	{
		simpleLoginpage.AddDealbutton();
	}
	
	@Then("^Validate the heading$")
	public void Validate_the_heading()
	{
		simpleLoginpage.DealHeading();
	}
	
	@When("^Select CompanyName < Goldman Bullion Ltd >$")
	public void Select_CompanyName()
	{
		simpleLoginpage.SelectCompany();
	}
	@And("^Select Branch < London >$")
	public void Select_Branch ()
	{
		simpleLoginpage.SelectBranch();
	}
	@And("^Select the Transaction Type < Sell Currency >$")
	public void Select_the_Transaction_Type ()
	{
		simpleLoginpage.SelectTransactionType();
	}
	@And("^Select the Currency  <PHP - Pesso>$")
	public void Select_the_Currency ()
	{
		simpleLoginpage.SelectCurrency();
	}
	@And("^Enter the Amount$")
	public void Enter_the_Amount (List<AddDeal> addDeal)
	{
		simpleLoginpage.EnterAmount(addDeal);
	}
	@And("^Select the date$")
	public void Select_the_date ()
	{
		simpleLoginpage.SelectDate();
	}
	@And("^Click on Denomination part$")
	public void Click_on_Denomination_part ()
	{
		simpleLoginpage.SelectDeno();
	}
	@Then("^Validate Denomination Pop-Up box$")
	public void Validate_Denomination_box ()
	{
		simpleLoginpage.ValidateDenoBox();
	}
	@When("^Enter the Denomination Value$")
	public void Enter_the_Denomination_Value(List<AddDeal> addDeal) throws Exception
	{
		simpleLoginpage.EnterDeno(addDeal);
	}
	@Then("^Click on ok$")
	public void Click_on_ok ()
	{
		simpleLoginpage.ClickOk();
	}
	@And("^Enter the Handling Fee and Commission$")
	public void Enter_the_Handling_Fee_and_Commission(List<AddDeal> addDeal) throws Exception
	{
		simpleLoginpage.EnterFeeCommission(addDeal);
	}
	@And("^Click on ADD CURRENCY$")
	public void Click_on_ADD_CURRENCY()
	{
		simpleLoginpage.AddCurrency();
	}
	@Then("^Check the Transaction Field$")
	public void Check_the_Transaction_Field()
	{
		simpleLoginpage.CheckTransField();
	}
	@And("^Check the Total Settlement$")
	public void Check_the_Total_Settlement ()
	{
		simpleLoginpage.CheckSettlement();
	}
	@When("^Click on Complete Transaction$")
	public void Click_on_Complete_Transaction ()
	{
		simpleLoginpage.CompleteTransaction();
	}
	@And("^validate DEAL SUMMARY pop-up$")
	public void validate_pop_up ()
	{
		simpleLoginpage.Popup();
	}
	@When("^Click on order Tab$")
	public void Click_on_order_Tab()
	{
		simpleLoginpage.OrderTab();
	}
	@Then("^Validate the order heading$")
	public void Validate_the_order_heading()
	{
		simpleLoginpage.OrderHeading();
	}
	@Given("^Redirect Deal Tab URL$")
	public void Redirect_Deal_Tab_URL() 
	{
		simpleLoginpage.RedirectDeal();
		
	}
	@And("^Click on Currency A/C Deal Button$")
	public void Click_on_Currency_AC_Deal_Button() 
	{
		simpleLoginpage.ClickACDeal();
		
	}
	@Then("^Validate the Heading$")
	public void Validate_the_Heading() 
	{
		simpleLoginpage.ValiHeadingAC();
		
	}
	@When("^Select the Company Name < Goldman Bullion Ltd >$")
	public void Select_the_Company_Name()
	{
		simpleLoginpage.SelectCompany1();
	}
	@And("^Select the Branch < London >$")
	public void Select_the_Branch()
	{
		simpleLoginpage.SelectBranch1();
	}
	@And("^Select the Transaction Type to < Sell Currency >$")
	public void Select_the_Transaction_Type_to()
	{
		simpleLoginpage.SelectTransactionType1();
	}
	@When("^Select the Currency to  <USD - United States Dollar>$")
	public void Select_the_Currency_to() 
	{
		simpleLoginpage.SelectCurrency1();
	}
	@And("^Enter the currency Amount$")
	public void Enter_the_currency_Amount(List<AddDeal> addDeal) throws Exception
	{
		simpleLoginpage.EnterAmount1(addDeal);
	}
	@And("^Click on Denomination$")
	public void Click_on_Denomination()
	{
		simpleLoginpage.SelectDeno1();
	}
	@And("^Enter Handling Fee and Commission$")
	public void Enter_Handling_Fee_and_Commission(List<AddDeal> addDeal) throws Exception
	{
		simpleLoginpage.EnterFeeCommission1(addDeal);
	}
	@And("^Click ADD CURRENCY$")
	public void Click_ADD_CURRENCY()
	{
		simpleLoginpage.AddCurrency1();
	}
	@And("^Check Total Settlement$")
	public void Check_Total_Settlement ()
	{
		simpleLoginpage.CheckSettlement1();
	}
	@Then("^Check Transaction Field$")
	public void Check_Transaction_Field()
	{
		simpleLoginpage.CheckTransField1();
	}
	@Given("^Redirect to order Tab$")
	public void Redirect_to_order_Tab()
	{
		simpleLoginpage.RedirOrder();
	}
	@Then ("^validate the heading$")
	public void validate_the_heading()
	{
		simpleLoginpage.validateheading();
	}
	@And ("^Validate total Buy and buy amount$")
	public void Validate_total_Buy_and_buy_amount()
	{
		simpleLoginpage.validatetotalBuy();
	}
	@When("^Click on view Button$")
	public void Click_on_view_Button()
	{
		simpleLoginpage.validateView();
	}

    @Then("^validate the view pop up$")
    public void validate_the_view_pop_up()
    {
    	simpleLoginpage.CheckAllBuy();
    }
    
    @When("^Click on Orders tab$")
    public void Click_on_Orders_tab()
    {
    	simpleLoginpage.ClickOrder();
    }
    @Then("^Validate the Order heading$")
    public void Validate_the_Order_heading()
    {
    	simpleLoginpage.ValidateOrder();
    }
    @When("^Click on the Denomination$")
    public void Click_on_the_Denomination()
    {
    	simpleLoginpage.ClickDenomination();
    }
    @Then("^Check the pop up box$")
    public void Check_the_pop_up_box()
    {
    	simpleLoginpage.Checkpopup();
    }
    @And("^Validate the denomination value$")
    public void Validate_the_denomination_value()
    {
    	simpleLoginpage.ValidateDenomination();
    }
    @Then("^Close the pop up box$")
    public void Close_the_pop_up_box()
    {
    	simpleLoginpage.Closepopup();
    }
    @When("^Click on Payment Received Slider$")
    public void Click_on_Payment_Received_Slider()
    {
    	simpleLoginpage.ClickPaymentReceived();
    }
   
    @When("^Click on Transaction Type$")
    public void Click_on_Transaction_Type()
    {
    	simpleLoginpage.ClickTransactionType();
    }
    @And("^Select Transaction Type < Sell Currency >$")
    public void Select_Transaction_Type_as()
    {
    	simpleLoginpage.SelecttheTransactionType();
    }
    @Then("^Validate the Green Pending button$")
    public void Validate_Success_Message()
    {
  	simpleLoginpage.ClickPaymentReceivedMessage();
    }
    @And("^Select Transaction Type < Buy Currency >$")
    public void Select_Transaction_Type_as_Buy()
    {
    	simpleLoginpage.SelecttheTransactionTypeBuy();
    }
    @When("^Click on the Payment Received Slider Button$")
    public void Click_on_the_Payment_Received_Slider_Buttonr()
    {
    	simpleLoginpage.ClickPaymentReceived1();
    }
    @Then("^Validate Pending Button$")
    public void Validate_Pending_Button()
    {
  	simpleLoginpage.ClickPaymentReceivedMessage1();
    }
    @When("^Click on Pending$")
    public void When_Click_on_Pending()
    {
    simpleLoginpage.ClickPending();
    }
    @Then("^Validate the pop up box$")
    public void Validate_the_pop_up_box()
    {
    	simpleLoginpage.ValidatePopup();
    }
    @And("Click on Settlement Denomination")
    public void Click_on_Settlement_Denomination()
    {
    	simpleLoginpage.SettlementDeno();
    }
    @When("Enter the Bag Number")
    public void Enter_the_Bag_Number(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterBagNo(addDeal);
    }
    @Then("Click on Update Transaction button")
    public void Click_on_Update_Transaction_button()
    {
    	simpleLoginpage.UpdateTrans();
    }
    @When("Enter Bag Number")
    public void Enter_Bag_Number(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterBagNo1(addDeal);
    }
    @Then("Click on the Update Transaction button")
    public void Click_on_the_Update_Transaction_button()
    {
    	simpleLoginpage.UpdateTrans1();
    }
    @When("^Click on the Pending$")
    public void When_Click_on_the_Pending()
    {
        simpleLoginpage.ClickPending1();
    }
    @When("^Click on Download Button$")
    public void Click_on_Download_Button()
    {
    	simpleLoginpage.ClickDownload();	
    }
    @Then("^Validate the downloaded file$")
    public void Validate_the_downloaded_file()
    {
    	simpleLoginpage.ValidateDownload();
    }
    @When("^Click on Summary Report button$")
    public void click_on_Summary_Report_button()
    {
    	simpleLoginpage.ClickSummaryDownload();
    }
    @When("^Click on download invoice icon$")
    public void Click_on_download_invoice_icon()
    {
    	simpleLoginpage.ClickInvoiceDownload();
    }
    @When("^Click on Deactivate Icon$")
    public void Click_on_Deactivate_Icon()
    {
    	simpleLoginpage.ClickDeactivate();
    }
    @Then("^validate pop up box$")
    public void validate_pop_up_box()
    {
    	simpleLoginpage.ClickValidateDeactivate();
    }
    @When("enter the Reason")
    public void enter_the_Reason(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterReason(addDeal);
    }
    @Then("^click on Yes Button$")
    public void click_on_Yes_Button()
    {
    	simpleLoginpage.ClickYesButton();
    }
    @When("^click on Company Dropdown$")
    public void click_on_Company_Dropdown()
    {
    	simpleLoginpage.ClickCompanyDropdown();
    }
    @And("^select Monex$")
    public void select_Monex()
    {
    	simpleLoginpage.SelectCompany2();
    }
    @Then("^validate Company name Monex$")
    public void validate_Company_name_Monex()
    {
    	simpleLoginpage.ValidateCompany2();
    }
    @When("^click on Branch Dropdown$")
    public void click_on_Branch_Dropdown()
    {
    	simpleLoginpage.ClickBranchDropdown();
    }
    @And("^select Paddington$")
    public void select_Paddington()
    {
    	simpleLoginpage.SelectBranch2();
    }
    @Then("^validate Branch name Paddington$")
    public void validate_Branch_name_Paddington()
    {
    	simpleLoginpage.ValidateBranch();
    }
    @When("^click on Deal Type Dropdown$")
    public void click_on_Deal_Type_Dropdown()
    {
    	simpleLoginpage.ClickDealDropdown();
    }
    @And("^select Direct Deal$")
    public void select_Direct_Deal()
    {
    	simpleLoginpage.SelectDeal();
    }
    @Then("^validate Deal Type Direct Deal$")
    public void validate_Deal_Type_Direct_Deal()
    {
    	simpleLoginpage.ValidateDeal();
    }
    @When("^click on Currency$")
    public void  click_on_Currency()
    {
    	simpleLoginpage.ClickCurrency();
    }
    @And("^select Currency AUD$")
    public void select_Currency_AUD()
    {
    	simpleLoginpage.SelectCurrency2();
    }
    @Then("^validate Currency AUD$")
    public void validate_Currency_AUD()
    {
    	simpleLoginpage.ValidateCurrency();
    }
    @When("^click on Transaction Type$")
    public void  click_on_Transaction_Type()
    {
    	simpleLoginpage.ClickTransactiontype();
    }
    @And("^select Transaction Type Buy Currency$")
    public void select_Transaction_Type_Buy_Currency()
    {
    	simpleLoginpage.SelectTransatype();
    }
    @Then("^validate Transaction Type Buy Currency$")
    public void validate_Transaction_Type_Buy_Currency()
    {
    	simpleLoginpage.ValidateTranstype();
    }
    @When("^enter the Deal Number$")
    public void  enter_the_Deal_Number(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterDealNo(addDeal);
    }
    @Then("^validate Deal No GBPNOSLF21056$")
    public void validate_Deal_No_GBPNOSLF21056()
    {
    	simpleLoginpage.ValidateDealNo();
    }
    @When("^click on Transaction Date$")
    public void  click_on_Transaction_Date()
    {
    	simpleLoginpage.ClickTransactionDate();
    }
    @And("^Select Start Date and End Date$")
    public void Select_Start_Date_and_End_Date()
    {
    	simpleLoginpage.SelectDates();
    }
    @Then("^validate selected Date$")
    public void validate_selected_Date()
    {
    	simpleLoginpage.ValidateSelectedDates();
    }
    @When("^click on Payment Received$")
    public void  click_on_Payment_Received()
    {
    	simpleLoginpage.ReceivePay();
    }
    @And("^Select Payment status Payment Received$")
    public void Select_Payment_status_Payment_Received()
    {
    	simpleLoginpage.SelectPay();
    }
    @Then("^validate Payment status Payment Received$")
    public void validate_Payment_status_Payment_Received()
    {
    	simpleLoginpage.ValidatePay();
    }
    @When("^Redirect to Stocks Tab$")
    public void Redirect_to_Stocks_Tab()
    {
    	simpleLoginpage.ClickStock();
    }
    @Then("^validate Stocks heading$")
    public void validate_Stocks_heading()
    {
    	simpleLoginpage.ValidateStockHeading();
    }
    @When("^Click on Select Till$")
    public void  Click_on_Select_Till()
    {
    	simpleLoginpage.ClickTill();
    }
    @And("^select Till 01 in dropdown$")
    public void select_Till_01_in_dropdown()
    {
    	simpleLoginpage.SelectTill();
    }
    @Then("^Validate Till 1$")
    public void Validate_Till_1()
    {
    	simpleLoginpage.ValidateTill();
    }
    @When("^Click on Select Currency$")
    public void  Click_on_Select_Currency()
    {
    	simpleLoginpage.SelectCurrency3();
    }
    @And("^select USD$")
    public void select_USD()
    {
    	simpleLoginpage.SelectUSD();
    }
    @Then("^Validate Currency USD$")
    public void Validate_Currency_USD()
    {
    	simpleLoginpage.ValidateUSD();
    }
    @When("^Click on Select Status$")
    public void  Click_on_Select_Status()
    {
    	simpleLoginpage.SelectStatus();
    }
    @And("^Select Status Out of stock$")
    public void Select_Status_Out_of_stock()
    {
    	simpleLoginpage.SelectStatus1();
    }
    @Then("^validate Status Out of stock$")
    public void validate_Status_Out_of_stock()
    {
    	simpleLoginpage.ValidateStatus();
    }
    @When("^Click the Date$")
    public void  Click_on_the_Date()
    {
    	simpleLoginpage.ClickDate();
    }
    @And("^Select Date$")
    public void Select_Date()
    {
    	simpleLoginpage.SelectDate1();
    }
    @Then("^Validate Date$")
    public void Validate_Date()
    {
    	simpleLoginpage.ValidateDate();
    }
    @When("^Click on Download button$")
    public void  Click_on_Download_button()
    {
    	simpleLoginpage.ClickDownloads();
    }
    @Then("^Validate the download file$")
    public void Validate_the_download_file()
    {
    	simpleLoginpage.ValidateDate();
    }
    
    @When("^Click on Exchange Rates tab$")
    public void  Click_on_Exchange_Rates_tab()
    {
    	simpleLoginpage.ClickExchange();
    }
    @And("^Select Exchange Rates$")
    public void Select_Exchange_Rates()
    {
    	simpleLoginpage.SelectExchange();
    }
    @Then("^Validate Heading EXCHANGE RATE$")
    public void Validate_Heading_EXCHANGE_RATE()
    {
    	simpleLoginpage.ValidateHeading();
    }
    
    @When("^Click on plus icon in Comapany$")
    public void  Click_on_plus_icon_in_Comapany()
    {
    	simpleLoginpage.Clickplusicon();
    }
    @And("^Enter the Company Name$")
    public void Validate_Heading_EXCHANGE_RATE(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterCompanyName(addDeal);
    }
    
    @Then("^Click on Add Company$")
    public void Click_on_Add_Company()
    {
    	simpleLoginpage.ClickAddCompany();
    }
    @When("^Click on plus icon next to Select Branch$")
    public void  Click_on_plus_icon_next_to_Select_Branch()
    {
    	simpleLoginpage.ClickAddBranch();
    }
    
    @Then("^Click on Select Company$")
    public void  Click_on_Select_Company()
    {
    	simpleLoginpage.ClickSelectBranch();
    }
    @And("^select Company monex$")
    public void select_Company_monex()
    {
    	simpleLoginpage.SelectCompany3();
    }
    @When("^Click on Branch Name$")
    public void  Click_on_Branch_Name()
    {
    	simpleLoginpage.ClickBranchName();
    }
    @And("^Enter Branch Name$")
    public void Enter_Branch_Name(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterBranchName(addDeal);
    }
    @When("^click on Branch Code$")
    public void  click_on_Branch_Code()
    {
    	simpleLoginpage.ClickBranchCode();
    }
    
    @And("^Enter Branch Code$")
    public void Enter_Branch_Code(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterBranchCode(addDeal);
    }
    @When("^click on Address Line 1$")
    public void  click_on_Address_Line_1()
    {
    	simpleLoginpage.ClickAddress1();
    }
    
    @And("^Enter Address Line1$")
    public void Enter_Address_Line1(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterAddress1(addDeal);
    }
    @When("^click on Address Line 2$")
    public void  click_on_Address_Line_2()
    {
    	simpleLoginpage.ClickAddress2();
    }
    @And("^Enter Address Line2$")
    public void Enter_Address_Line2(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterAddress2(addDeal);
    }
    @When("^click on City$")
    public void  click_on_City()
    {
    	simpleLoginpage.ClickCity();
    }
    @And("^Enter City$")
    public void Enter_City(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterCity(addDeal);
    }
    @When("^click on State$")
    public void  click_on_State()
    {
    	simpleLoginpage.ClickState();
    }
    @And("^Enter State$")
    public void Enter_State(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterState(addDeal);
    }
    @When("^click on Postal Code$")
    public void  click_on_Postal_Code()
    {
    	simpleLoginpage.ClickPostal();
    }
    @And("^Enter Postal Code$")
    public void Enter_Postal_Code(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterPostal(addDeal);
    }
    @When("^click on Name$")
    public void  click_on_Name()
    {
    	simpleLoginpage.ClickName();
    }
    @And("^Enter Name$")
    public void Enter_Name(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterName(addDeal);
    }
    @When("^click on Email$")
    public void  click_on_Email()
    {
    	simpleLoginpage.ClickEmail();
    }
    @And("^Enter Email$")
    public void Enter_Email(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterEmail(addDeal);
    }
    @When("^click on Contact No$")
    public void  click_on_Contact_No()
    {
    	simpleLoginpage.ClickContactNo();
    }
    @And("^Enter Contact No$")
    public void Enter_Contact_No(List<AddDeal> addDeal) throws Exception
    {
    	simpleLoginpage.EnterContactNo(addDeal);
    }
    @When("^Click Add Branch Button$")
    public void  Click_Add_Branch_Button()
    {
    	simpleLoginpage.ClickBranch();
    }
    @When("^Clicking on Select Company$")
    public void  Clicking_on_Select_Company()
    {
    	simpleLoginpage.ClickingSelectCompany();
    }
    @And("^Select company Monex$")
    public void Select_company_Monex()
    {
    	simpleLoginpage.SelectMonex();
    }
    @When("^Clicking on Select Branch$")
    public void  Clicking_on_Select_Branch()
    {
    	simpleLoginpage.ClickingSelectBranch();
    }
    @And("^Select Branch Quinton$")
    public void Select_Branch_Quinton()
    {
    	simpleLoginpage.SelectQuinton();
    }
    @When("^Click on Branch Copy$")
    public void  Click_on_Branch_Copy()
    {
    	simpleLoginpage.ClickBranchCopy();
    }
    @Then("^Validate Target Branch Details$")
    public void Validate_Target_Branch_Details()
    {
    	simpleLoginpage.ValidateTarget();
    }
    @When("^Clicking on the Select Company$")
    public void  Clicking_on_the_Select_Company()
    {
    	simpleLoginpage.ClickingonSelectCompany();
    }
    @And("^Select the company MoneyCorp$")
    public void Select_the_company_MoneyCorp()
    {
    	simpleLoginpage.SelectingMoneyCorp();
    }
    @When("^Click on the Select Branch$")
    public void  Click_on_the_Select_Branch()
    {
    	simpleLoginpage.ClickingonSelectBranch();
    }
    @And("^Select the Branch Vault$")
    public void Select_the_Branch_Vault()
    {
    	simpleLoginpage.SelectonVault();
    }
    @Then("^Click on the Save button$")
    public void  Click_on_the_Save_button()
    {
    	simpleLoginpage.ClickingSave();
    }
}   
	
