package com.bankingcore.automationutil;

import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.imageio.ImageIO;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;

/**
 * @author madusanka@codelantic.com
 *
 *         <br/>
 *         projectType--> (customer, admin, agent)
 */
public class App_old {

	private static final String CUSTOMER_DRIVE_PATH = "https://drive.google.com/drive/folders/1MBKt1oiMOSSYfjpxAD9A3zQ7u_eVicez?usp=sharing";
	private static final String ADMIN_DRIVE_PATH = "https://drive.google.com/drive/folders/1sE70OSoBPJLn6bK5y7jH2pLMJe2qtzjO?usp=sharing";
	private static final String AGENT_FRIVE_PATH = "https://drive.google.com/drive/folders/1-tiDKA9-2bLVRKs_Fb9h7mMZagLJ-NvZ?usp=sharing";

	private static final String CUSTOMER_IMAGE_PATH = "https://drive.google.com/uc?id=1z-G5qQQyxiyzq2lHl_MGUKg1g-jPlUEF";
	private static final String ADMIN_IMAGE_PATH = "https://drive.google.com/uc?id=1WiKO-EIWzmCGF0VbPJTMWPPdx2wSIWAB";
	private static final String AGENT_IMAGE_PATH = "https://drive.google.com/uc?id=1vL3cOi3PbcnwU02WpLbPToLI4QMvi-d-";

	private static final String DATE_TIME_FORMAT = "yyyyMMdd_HHmmss";

	private static final String BASE_PATH = "/opt-automation/automation-results/spoton-money/";
	private static final String SERVER_BASE_PATH = "https://codelantic-automation.tk/Automation/";

	private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);

	private static String dateTimeString = dateTimeFormatter.format(LocalDateTime.now());

//	public static void main(String[] args) {
//
//		try {
//			String path = getBasePath(args[0]);
//
//			openReport(path);
//
//			takeScreenShot(args[0]);
//
//			createZipFile(path, args[0]);
//
//			Thread.sleep(5000);
//
//			uploadImagesToServer(args[0]);
//
//			Thread.sleep(10000);
//
//			sendEmail(args[0]);
//
//			closeBrowser();
//
//			System.exit(0);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			System.exit(0);
//		}
//	}

	/**
	 * return base project path based on project type
	 * 
	 * @param projectType
	 * @return path
	 * @throws Exception
	 */
	private static String getBasePath(String projectType) throws Exception {
		String path = "";
		File configData = new File("C:\\configData_" + projectType + ".txt");
		Scanner myReader = new Scanner(configData);
		while (myReader.hasNextLine()) {
			path = myReader.nextLine();
		}
		myReader.close();
		return path;
	}

	/**
	 * opens default web browser with cucumber report
	 * 
	 * @param path
	 * @throws Exception
	 */
	private static void openReport(String path) throws Exception {
		File report = new File(path + "\\target\\reports\\html-reports\\cucumber-html-reports\\overview-features.html");

		Desktop d = Desktop.getDesktop();
		d.browse(report.toURI());
		Thread.sleep(20000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_END);
		robot.keyRelease(KeyEvent.VK_END);
		Thread.sleep(2000);
	}

	/**
	 * capture screen shot
	 * 
	 * @param projectType
	 * @throws Exception
	 */
	private static void takeScreenShot(String projectType) throws Exception {
		System.out.println(Toolkit.getDefaultToolkit().getScreenResolution());

		Date nowDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);

		Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		BufferedImage capture = new Robot().createScreenCapture(screenRect);

		File baseDir = new File(BASE_PATH + projectType + "-portal/");
		if (!baseDir.exists()) {
			baseDir.mkdirs();
		}

		File imageFile = new File(BASE_PATH + projectType + "-portal/screenshot_" + projectType + ".png");
		if (imageFile.exists()) {
			Path temp = Files.move(Paths.get(imageFile.getPath()),
					Paths.get("/opt-automation/automation-results/spoton-money/archived/" + projectType
							+ "-portal/screenshot_" + projectType + "_" + sdf.format(nowDate) + ".png"));
			if (temp != null) {
				System.out.println("File renamed and moved successfully");
			} else {
				System.out.println("Failed to move the file");
			}
		}
		ImageIO.write(capture, "png", imageFile);
		System.out.println(imageFile.exists());
	}

	/**
	 * close the web browser
	 * 
	 * @throws Exception
	 */
	private static void closeBrowser() throws Exception {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_F4);
	}

	/**
	 * creating a zip file for reports
	 * 
	 * @param sourcePath
	 * @param projectType
	 */
	private static void createZipFile(String sourcePath, String projectType) throws Exception {
		ZipUtil zipUtil = new ZipUtil();
		File baseDir = new File(BASE_PATH + projectType + "-portal/");
		if (!baseDir.exists()) {
			baseDir.mkdirs();
		}
		Date nowDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);

		String zipFilePath = BASE_PATH + projectType + "-portal/" + projectType + ".zip";
		File htmlFile = new File(BASE_PATH + projectType + "-portal/" + projectType);
		if (htmlFile.exists()) {
			zipUtil.zipIt(zipFilePath, BASE_PATH + projectType + "-portal/" + projectType);

			// moving current zip file to archived location
			File oldFile = new File(BASE_PATH + projectType + "-portal/" + projectType + ".zip");
			if (oldFile.exists()) {
				Path temp = Files.move(Paths.get(oldFile.getPath()),
						Paths.get("/opt-automation/automation-results/spoton-money/archived/" + projectType + "-portal/"
								+ projectType + "_" + sdf.format(nowDate) + ".zip"));
				if (temp != null) {
					System.out.println("File renamed and moved successfully");
				} else {
					System.out.println("Failed to move the file");
				}
			}
			deleteDir(htmlFile);
		}

		final Path sourceDirectory = Paths.get(sourcePath + "\\target\\reports\\html-reports\\cucumber-html-reports\\");
		final Path targetDirectory = Paths.get(BASE_PATH + projectType + "-portal/" + projectType);

		Files.walkFileTree(sourceDirectory, new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult preVisitDirectory(final Path dir, final BasicFileAttributes attrs)
					throws IOException {
				Files.createDirectories(targetDirectory.resolve(sourceDirectory.relativize(dir)));
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFile(final Path file, final BasicFileAttributes attrs) throws IOException {
				Files.copy(file, targetDirectory.resolve(sourceDirectory.relativize(file)));
				return FileVisitResult.CONTINUE;
			}
		});

	}

	/**
	 * sending email using email service (need to up run on port 6002)
	 * 
	 * @param projectType
	 * @throws Exception
	 */
	private static void sendEmail(String projectType) throws Exception {

		List<String> toAddress = new ArrayList<String>();

		File configData = new File("C:\\addressList.txt");
		Scanner myReader = new Scanner(configData);
		while (myReader.hasNextLine()) {
			toAddress.add(myReader.nextLine());
		}
		myReader.close();

//		List<String> fileList = new ArrayList<String>();
//		File zipFile = new File("/opt/automation/zip/" + projectType + ".zip");
//		File zipFileEmailed = new File("/opt/automation/zip/" + projectType + ".zip1");
//		zipFile.renameTo(zipFileEmailed);
//
//		fileList.add(zipFileEmailed.getPath());
//		fileList.add(BASE_PATH + projectType + "-portal/screenshot_" + projectType + ".png");

		LocalDateTime localDateTime = LocalDateTime.now();
		String dateTime = localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

		MessageDto messageDto = new MessageDto();
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("dateTime", dateTime);
		if (projectType.equals("customer")) {
			data.put("driveUrl", CUSTOMER_DRIVE_PATH);
			data.put("portal", "Customer Portal");
//			data.put("imageUrl", CUSTOMER_IMAGE_PATH);
			data.put("imageUrl",
					SERVER_BASE_PATH + projectType + "/screenshot_" + projectType + "_" + dateTimeString + ".png");
			messageDto.setSubject("Monex Money Transfer - Automation Test Summary - Customer Portal");
		} else if (projectType.equals("agent")) {
			data.put("driveUrl", AGENT_FRIVE_PATH);
			data.put("portal", "Agent Portal");
			data.put("imageUrl",
					SERVER_BASE_PATH + projectType + "/screenshot_" + projectType + "_" + dateTimeString + ".png");
			messageDto.setSubject("Monex Money Transfer - Automation Test Summary - Agent Portal");
		} else if (projectType.equals("admin")) {
			data.put("driveUrl", ADMIN_DRIVE_PATH);
			data.put("portal", "Admin Portal");
			data.put("imageUrl",
					SERVER_BASE_PATH + projectType + "/screenshot_" + projectType + "_" + dateTimeString + ".png");
			messageDto.setSubject("Monex Money Transfer - Automation Test Summary - Admin Portal");
		}

		messageDto.setTemplateName("qa_automation");
		messageDto.setToAddress(toAddress);
//		messageDto.setFileList(fileList);
		messageDto.setData(data);

		DefaultHttpClient httpClient = new DefaultHttpClient();

		HttpPost postRequest = new HttpPost("http://localhost:6002/v1/communication/email/template/awsmessage");

		postRequest.addHeader("content-type", "application/json");

		Gson gson = new Gson();
		StringEntity userEntity = new StringEntity(gson.toJson(messageDto, MessageDto.class));
		postRequest.setEntity(userEntity);

		HttpResponse response = httpClient.execute(postRequest);

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode != 200) {
			throw new RuntimeException("Failed with HTTP error code : " + statusCode);
		} else {
			System.out.println("Message Sent.");
		}
	}

	private static void deleteDir(File file) {
		File[] contents = file.listFiles();
		if (contents != null) {
			for (File f : contents) {
				deleteDir(f);
			}
		}
		file.delete();
	}

	/**
	 * FTP file upload
	 * 
	 * @param projectType
	 */
	private static void uploadImagesToServer(String projectType) {
		FTPConnectionUtil ftpConnectionUtil = new FTPConnectionUtil();

		ftpConnectionUtil.openConnection();
		File imageFile = new File(BASE_PATH + projectType + "-portal/screenshot_" + projectType + ".png");
		ftpConnectionUtil.uploadFile(imageFile,
				projectType + "/screenshot_" + projectType + "_" + dateTimeString + ".png");
		ftpConnectionUtil.closeConnection();
	}
}
