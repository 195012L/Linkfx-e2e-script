package com.codelantic.tests.customer;

import com.codelantic.pages.customer.*;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class SignUpTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private HomePage homePageObj;
    private SignUpPF signUpPFObj;
    private SignUp2PF signUp2PFObj;
    private SignUp3PF signUp3PFObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }
            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            homePageObj = new HomePage(driver, commonOpObj);
            signUpPFObj = new SignUpPF(driver, commonOpObj);
            signUp2PFObj =  new SignUp2PF(driver, commonOpObj);
            signUp3PFObj = new SignUp3PF(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }

    @Test
    public void signupFlowTest(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE,Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        signUp3PFObj.clickOnCOntinueBtn();
        signUpPFObj.closeNotifications();
        Assert.assertTrue( homePageObj.isUserCreatedcongratsMsgShowing());
    }

    @Test
    @Parameters({"SIGNUP1_FN", "SIGNUP1_LN", "SIGNUP1_CONTACTNO", "SIGNUP1_UN", "SIGNUP1_PSWD", "SIGNUP1_CNFM_PSWD",
            "SIGNUP1_ADDRS", "SIGNUP1_POSTCODE", "SIGNUP1_COUNTRY"
    })
    public void signupFlowTest_Get_Param_From_XML(String SIGNUP1_FN, String SIGNUP1_LN, String SIGNUP1_CONTACTNO, String SIGNUP1_UN, String SIGNUP1_PSWD, String SIGNUP1_CNFM_PSWD, String SIGNUP1_ADDRS,String SIGNUP1_POSTCODE, String SIGNUP1_COUNTRY){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(SIGNUP1_FN, SIGNUP1_LN, SIGNUP1_CONTACTNO, SIGNUP1_UN, SIGNUP1_PSWD, SIGNUP1_CNFM_PSWD,
                SIGNUP1_ADDRS, SIGNUP1_POSTCODE, SIGNUP1_COUNTRY);
//        signUpPFObj.clickOnContinueBtn();
//        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE,Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
//                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
//                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
//        signUp2PFObj.clickOnContinueBtn();
//        signUp3PFObj.clickOnCOntinueBtn();
//        signUpPFObj.closeNotifications();
//        Assert.assertTrue( homePageObj.isUserCreatedcongratsMsgShowing());
    }


    public void signUpPFTest(){

    }

    public void signUpPF2Test(){

    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }


}
