package com.codelantic.pages.transactions;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Keys;

import static com.codelantic.utilities.Constants.EXPLICIT_TIMEOUT;

public class SATransferDetailsPF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SATransferDetailsPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By sendingFromCountryInputFieldValue = By.xpath("//label[contains(text(), \"Sending From\")]//parent::nz-form-label//following-sibling::nz-form-control//child::input");
    private By recipientCountryInputFieldValue = By.xpath("//label[contains(text(), \"Recipient Country\")]//parent::nz-form-label//following-sibling::nz-form-control//child::input");
    private By sendAmountInputField = By.id("sendAmount");
    private By amountReceivedInputField = By.id("amountReceived");
    private By modeOfTranferInputField = By.xpath("//label[contains(text(), \"Mode of Transfer\")]//parent::nz-form-label//following-sibling::nz-form-control//child::input");
    private By tranferFeesInputField = By.xpath("//label[contains(text(), \"Transfer Fees\")]//parent::nz-form-label//following-sibling::nz-form-control//child::input");
    private By continueBtn = By.xpath("//span[contains(text(), \"Continue\")]//parent::span//parent::button");
    private By loader = By.cssSelector(".loader");

    public void setSendingFromCountryInputField(String country) {
        //WebElement sendingFromCountry = commonOpObj.waitUntilElementClickable(sendingFromCountryInputFieldValue, EXPLICIT_TIMEOUT);
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)) {
            WebElement sendingFromCountry = driver.findElement(sendingFromCountryInputFieldValue);
            sendingFromCountry.sendKeys(country);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            sendingFromCountry.sendKeys(Keys.ENTER);
        }

    }

    public void setRecipientCountryInputField(String country) {
        //WebElement recipientCountry = commonOpObj.waitUntilElementClickable(recipientCountryInputFieldValue, EXPLICIT_TIMEOUT);
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)) {
            WebElement recipientCountry = driver.findElement(recipientCountryInputFieldValue);
            recipientCountry.sendKeys(country);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            recipientCountry.sendKeys(Keys.ENTER);
        }

    }

    public void setSendAmountInputField(String amount) {
        //WebElement sendamount = commonOpObj.waitUntilElementClickable(sendAmountInputField, EXPLICIT_TIMEOUT);
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)) {
            WebElement sendamount = driver.findElement(sendAmountInputField);
            sendamount.sendKeys(amount);
        }
    }

    public void setAmountRecievedInputField(String amount) {
        //WebElement recipientCountry = commonOpObj.waitUntilElementClickable(amountReceivedInputField, EXPLICIT_TIMEOUT);
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)) {
            WebElement recipientCountry = driver.findElement(amountReceivedInputField);
            recipientCountry.sendKeys(amount);
        }
    }

    public void setModeOfTranferInputField(String mot) {
        //WebElement modeOfTransfer = commonOpObj.waitUntilElementClickable(modeOfTranferInputField, EXPLICIT_TIMEOUT);
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)) {
            WebElement modeOfTransfer = driver.findElement(modeOfTranferInputField);
            modeOfTransfer.sendKeys(mot);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            modeOfTransfer.sendKeys(Keys.ENTER);
        }

    }

    public void setTransferFeesInputField(String fee) {
        //WebElement transferFee = commonOpObj.waitUntilElementClickable(tranferFeesInputField, EXPLICIT_TIMEOUT);
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)) {
            WebElement transferFee = driver.findElement(tranferFeesInputField);
            transferFee.sendKeys(fee);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            transferFee.sendKeys(Keys.ENTER);
        }

    }

    public void ClickOnContinueBtn() {
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(continueBtn, EXPLICIT_TIMEOUT).click();
        }
    }

    public void fillTransferDetails(String sendingFrom, String recipientCountry, String sendAmount, String amountReceived, String modeOFTransfer, String transferFees) {
        setSendingFromCountryInputField(sendingFrom);
        setRecipientCountryInputField(recipientCountry);
        setSendAmountInputField(sendAmount);
        //setAmountRecievedInputField(amountReceived);*/
        setModeOfTranferInputField(modeOFTransfer);
        setTransferFeesInputField(transferFees);
        ClickOnContinueBtn();
    }
}
