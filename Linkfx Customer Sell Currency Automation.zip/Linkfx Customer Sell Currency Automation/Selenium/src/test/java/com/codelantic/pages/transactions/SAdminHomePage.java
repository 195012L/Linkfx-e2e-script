package com.codelantic.pages.transactions;

import com.codelantic.utilities.CommonOp;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import static com.codelantic.utilities.Constants.EXPLICIT_TIMEOUT;

public class SAdminHomePage {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SAdminHomePage(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By superAdminLogoText = By.cssSelector("div.logo span");
    private By makeTransferBtn = By.xpath("//span[contains(text(), \"MAKE TRANSFER\")]//parent::button");
    private By AMLcheckBtn = By.xpath("//span[contains(text(), \"AML CHECK\")]//parent::button");

    public String isSuperAdminLogoTextVisible(){
        return driver.findElement(superAdminLogoText).getText();
    }

    public void CLickOnMAkeTransfer(){
        commonOpObj.waitUntilElementClickable(makeTransferBtn, EXPLICIT_TIMEOUT).click();
    }

    public void ClickOnAMLcheckBtn(){
        driver.findElement(AMLcheckBtn).click();
    }


}
