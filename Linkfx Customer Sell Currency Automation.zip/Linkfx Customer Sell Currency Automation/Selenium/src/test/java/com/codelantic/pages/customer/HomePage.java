package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.sun.corba.se.impl.orbutil.closure.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class HomePage {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    private By sendingCountryIF = By.xpath("//ng-select[@formcontrolname=\"sendingCountry\"]/descendant::input");
    private By recipientCountryIF = By.xpath("//ng-select[@formcontrolname=\"recipientCountry\"]/descendant::input");
    private By loader = By.cssSelector(".loader");
    private By mtGetStartedBtn = By.cssSelector(".get-started-btn");
    private By profileBtn = By.cssSelector(".profile-btn");
    private By signOutBtn = By.xpath("//li[text()=\"Sign Out\"]");
    private By settingMEnuItemLink = By.xpath("//li[text()=\"Settings\"]");
    private By closeBtn = By.cssSelector(".ant-modal-close-x");
    private By congratsUsrCreatedModal = By.tagName("app-success-message-modal"); //revisit
    private By sendAmountIF = By.xpath("//input[@formcontrolname=\"sendAmount\"]");
    private By amountReceivedIF = By.xpath("//input[@formcontrolname=\"amountReceived\"]");
    private By dropDownListUI = By.cssSelector(".ng-dropdown-panel-items");
    private By closeBtnOnForm = By.cssSelector(".ant-modal-close");
    private By myTransactions = By.xpath("//li[text()=\"My Transactions\"]");

    public HomePage(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    public void selectSendingCountry(String country){
        WebElement sendingCountry = driver.findElement(sendingCountryIF);
        sendingCountry.sendKeys(country);
        commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
        sendingCountry.sendKeys(Keys.ENTER);
    }

    public void setSendingCountryIF(String country) {
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement sendingFromCountry = commonOpObj.waitUntilElementClickable(sendingCountryIF, Constants.EXPLICIT_TIMEOUT);
            sendingFromCountry.click();
            sendingFromCountry.sendKeys(country);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            sendingFromCountry.sendKeys(Keys.ENTER);
        }
    }

    public void setRecipientCountryIF(String country) {
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement recipientFromCountry = commonOpObj.waitUntilElementClickable(recipientCountryIF, Constants.EXPLICIT_TIMEOUT);
            recipientFromCountry.click();
            recipientFromCountry.sendKeys(country);
            //commonOpObj.waitUntilElementvisibilityOf(dropDownListUI, Constants.EXPLICIT_TIMEOUT_FOR_DROP_DOWNS);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            recipientFromCountry.sendKeys(Keys.ENTER);
            //commonOpObj.waitUntilElementInvisibilityOfElementLocated(dropDownListUI, Constants.EXPLICIT_TIMEOUT_FOR_DROP_DOWNS);
        }
    }

    public void setSendAmountIF(String sAmount){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement setAMount = commonOpObj.waitUntilElementClickable(sendAmountIF, Constants.EXPLICIT_TIMEOUT);
            WebElement setAMount = driver.findElement(sendAmountIF);
            setAMount.sendKeys(sAmount);
            setAMount.sendKeys(Keys.ENTER);
        }
    }

    public void setAmountReceivedIF(String rAmount){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement setAMount = commonOpObj.waitUntilElementClickable(amountReceivedIF, Constants.EXPLICIT_TIMEOUT);
            setAMount.sendKeys(rAmount);
            setAMount.sendKeys(Keys.ENTER);
        }
    }

    public void fillSendMoneyFormWithValuesSet1_Get_started(String sendingCountry, String recipientCountry,
                                                String sendingAmount, String recievingAmount){

        By username = By.id("username"); //wait until login screen disappear
        if (commonOpObj.waitUntilElementInvisibilityOf(username, Constants.EXPLICIT_TIMEOUT)) {
            //setSendingCountryIF(sendingCountry);
            setRecipientCountryIF(recipientCountry);
            setSendAmountIF(sendingAmount);
            //setAmountReceivedIF(recievingAmount);
            clickOnGetStarted_make_transfer();
        }
    }

    public boolean waituntilLoginDisappear(){
        By username = By.id("username");
        return commonOpObj.waitUntilElementInvisibilityOfElementLocated(username, Constants.EXPLICIT_TIMEOUT);
    }

    public void clickOnGetStarted() {
        By username = By.id("username"); //wait until login screen disappear
        if (commonOpObj.waitUntilElementInvisibilityOf(username, Constants.EXPLICIT_TIMEOUT)) {
            driver.findElement(mtGetStartedBtn).click();
        }
    }

    public void clickOnGetStarted_make_transfer() {
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement webElement = commonOpObj.waitUntilElementClickable(mtGetStartedBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnProfileBtn(){
        commonOpObj.waitUntilElementClickable(profileBtn, Constants.EXPLICIT_TIMEOUT).click();
    }

    public void clickOnsignOutBtn(){
        commonOpObj.waitUntilElementClickable(signOutBtn,Constants.EXPLICIT_TIMEOUT).click();
    }

    public void clickOncloseBtnOnForm(){
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement webElement = commonOpObj.waitUntilElementClickable(closeBtnOnForm, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnMyTransactionsLink(){
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement webElement = commonOpObj.waitUntilElementClickable(myTransactions, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void logOutfromCP(){
        if(commonOpObj.waitUntilElementInvisibilityOfElementLocated(closeBtn, Constants.EXPLICIT_TIMEOUT)){
            clickOnProfileBtn();
            clickOnsignOutBtn();
        }
    }

    public boolean isUserCreatedcongratsMsgShowing(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(congratsUsrCreatedModal, Constants.EXPLICIT_TIMEOUT);
            return driver.getPageSource().contains(Constants.SIGNUP_USER_CREATED_CONGRATS_MSG);
        }
        return false;
    }

    public void clickOnsettingMEnuItemLink(){
        driver.findElement(settingMEnuItemLink).click();
    }

    public void goToMyTransactions(){
        clickOnProfileBtn();
        clickOnMyTransactionsLink();
    }

}
