package com.bankingcore.automationutil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipUtil {

	public void zipIt(String zipFile, String sourceFolder) {
		try {
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			File fileToZip = new File(sourceFolder);
			zipFileWithFolder(fileToZip, fileToZip.getName(), zipOut);
			zipOut.close();
			fos.close();

		} catch (Exception ex) {
			throw new IllegalStateException(String.format("Error happened archiving %s", sourceFolder), ex);
		}
	}

	public void deleteFileList(File node) {
		for (final File fileEntry : node.listFiles()) {
			if (fileEntry.isDirectory()) {
				deleteFileList(fileEntry);
//			} else if (fileEntry.getName().endsWith(".jpg") || fileEntry.getName().endsWith(".jpeg") || fileEntry.getName().endsWith(".png")) {
//				fileEntry.delete();
//			}
			} else if (!fileEntry.getName().endsWith(".zip")) {
				fileEntry.delete();
			}
		}
	}

	private static void zipFileWithFolder(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
		if (fileToZip.isHidden()) {
			return;
		}
		if (fileToZip.isDirectory()) {
			if (fileName.endsWith("/")) {
				zipOut.putNextEntry(new ZipEntry(fileName));
				zipOut.closeEntry();
			} else {
				zipOut.putNextEntry(new ZipEntry(fileName + "/"));
				zipOut.closeEntry();
			}
			File[] children = fileToZip.listFiles();
			for (File childFile : children) {
				zipFileWithFolder(childFile, fileName + "/" + childFile.getName(), zipOut);
			}
			return;
		}
		FileInputStream fis = new FileInputStream(fileToZip);
		ZipEntry zipEntry = new ZipEntry(fileName);
		zipOut.putNextEntry(zipEntry);
		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zipOut.write(bytes, 0, length);
		}
		fis.close();
	}

}
