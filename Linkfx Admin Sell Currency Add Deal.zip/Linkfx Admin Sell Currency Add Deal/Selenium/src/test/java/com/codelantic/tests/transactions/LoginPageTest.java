package com.codelantic.tests.transactions;

import com.codelantic.testbase.BaseTest;

public class LoginPageTest extends BaseTest {



}
