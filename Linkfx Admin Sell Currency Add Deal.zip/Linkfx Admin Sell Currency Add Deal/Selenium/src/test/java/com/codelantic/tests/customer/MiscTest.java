package com.codelantic.tests.customer;

import com.codelantic.pages.customer.*;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.NewSessionPayload;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class MiscTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignInPF signInPFObj;
    private HomePage homePageObj;
    private MTTransferDetailsPF mtTransferDetailsPFObj;
    private MTSenderPF mtSenderPFObj;
    private MTBeneficiaryPF mtBeneficiaryPFObj;
    private MTInvoicePF mtInvoicePFObj;
    private MTAccountDetails mtAccountDetailsObj;
    private MyTransactions myTransactionsObj;
    private NavMenu navMenuObj;
    private Beneficiaries beneficiariesObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }

            driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);
            driver.manage().window().maximize();

            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);
            homePageObj = new HomePage(driver, commonOpObj);
            mtTransferDetailsPFObj = new MTTransferDetailsPF(driver, commonOpObj);
            mtSenderPFObj = new MTSenderPF(driver, commonOpObj);
            mtBeneficiaryPFObj = new MTBeneficiaryPF(driver, commonOpObj);
            mtInvoicePFObj = new MTInvoicePF(driver, commonOpObj);
            mtAccountDetailsObj = new MTAccountDetails(driver, commonOpObj);
            myTransactionsObj  = new MyTransactions(driver, commonOpObj);
            navMenuObj = new NavMenu(driver, commonOpObj);
            beneficiariesObj = new Beneficiaries(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }

    @Test(invocationCount = 1, description = "Existing Beneficiary and Existing Bank")
    public void myTransfers(){

        String transferReference = "";
        String beniName = "";
        String transferdAmount = "";
        String recievedAmount = "";
        String status = Constants.TRANSACTIONS_STATUS_ACCEPTED;

        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.setPayementModeIF(Constants.PAYMODE_BANK_DEPOSIT);
        mtTransferDetailsPFObj.clickOnContinueBtn();

        mtSenderPFObj.clickOnContinueBtn();
        //mtVerifySenderDetailsSet1();
        //mtSenderPFObj.fillSenderDetailsIFsWithValueSet1(Constants.MOT_BANK_DEPOSIT);

        mtBeneficiaryPFObj.fillBenificiaryOldBeniOldBank(Constants.MT_SET1_BENI_NAME, Constants.MT_SET1_RECIPIENT_CNTRY);
        mtBeneficiaryPFObj.setReference(Constants.MT_SET1_REF);
        mtBeneficiaryPFObj.clickOnContinueBtn();

        //mtVerifyTransferDetailsWithInvoiceDetailsSet1();
        transferReference = mtInvoicePFObj.getinvoiceIF();
        beniName = mtInvoicePFObj.getbeneficiaryNameIF();
        transferdAmount = mtInvoicePFObj.gettransferredAmountIF();
        recievedAmount = mtInvoicePFObj.getreceivedAmountIF();

        Assert.assertEquals(mtInvoicePFObj.confirmAndCLoseTheTransaction(), Constants.MT_INVOICE_SUCCESS_NOTIFICATION);

        mtAccountDetailsObj.waitTillNotificationDetailsScreenAppeared();
        Assert.assertTrue(driver.getPageSource().contains(Constants.MT_ACC_DETAILS_PAYMENT_NOTE));
        Assert.assertEquals(mtAccountDetailsObj.getnotificationDesccription(), Constants.MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION);
        mtAccountDetailsObj.clickOncloseNotification();
        mtAccountDetailsObj.clickOnOkBTn();

        homePageObj.goToMyTransactions();

        commonOpObj.Sleep(1000);
        Assert.assertEquals(myTransactionsObj.getRow1transferRef(), transferReference);
        Assert.assertEquals(myTransactionsObj.getRow1beniName(), beniName);
        Assert.assertEquals(Integer.parseInt(myTransactionsObj.getRow1TransferdAmount()), (int)Double.parseDouble(transferdAmount));
        Assert.assertEquals(Integer.parseInt(myTransactionsObj.getRow1RecievedAMount()), (int)Double.parseDouble(recievedAmount));
        Assert.assertEquals(myTransactionsObj.getRow1Status(), status);

        navMenuObj.signOutfromCP();
        //homePageObj.logOutfromCP();
    }

    @Test(invocationCount = 1, description = "Existing Beneficiary and Existing Bank")
    public void myBeneficiaries(){

        String beniName = Constants.NEW_BENI_FULL_NAME;
        String beniAddress = Constants.NEW_BENI_ADRS;
        String beniContactNumber = Constants.NEW_BENI_cN;
        String beniFirstName = Constants.NEW_BENI_FN;

        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.setPayementModeIF(Constants.PAYMODE_BANK_DEPOSIT);
        mtTransferDetailsPFObj.clickOnContinueBtn();

        mtSenderPFObj.clickOnContinueBtn();
        //mtVerifySenderDetailsSet1();
        //mtSenderPFObj.fillSenderDetailsIFsWithValueSet1(Constants.MOT_BANK_DEPOSIT);

        mtBeneficiaryPFObj.fillBenificiaryNewBeniNewBank(Constants.NEW_BENI_FN,  Constants.NEW_BENI_lN, Constants.NEW_BENI_cN,
                Constants.NEW_BENI_ADRS, Constants.MT_SET1_RECIPIENT_CNTRY, Constants.NEW_BANK_BN, Constants.NEW_BANK_BACC,
                Constants.NEW_BANK_BB, Constants.NEW_BANK_BC, Constants.NEW_BANK_SFT);
        mtBeneficiaryPFObj.setReference(Constants.MT_SET1_REF);
        mtBeneficiaryPFObj.clickOnContinueBtn();

        //mtVerifyTransferDetailsWithInvoiceDetailsSet2();
        Assert.assertEquals(mtInvoicePFObj.confirmAndCLoseTheTransaction(), Constants.MT_INVOICE_SUCCESS_NOTIFICATION);

        mtAccountDetailsObj.waitTillNotificationDetailsScreenAppeared();
        Assert.assertTrue(driver.getPageSource().contains(Constants.MT_ACC_DETAILS_PAYMENT_NOTE));
        Assert.assertEquals(mtAccountDetailsObj.getnotificationDesccription(), Constants.MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION);
        mtAccountDetailsObj.clickOncloseNotification();
        mtAccountDetailsObj.clickOnOkBTn();

        homePageObj.goToMyTransactions();
        commonOpObj.Sleep(1000);

        navMenuObj.clickOnBeniLink();
        beneficiariesObj.waituntilBeniTableNameDisplayed();

        beneficiariesObj.setFilterByValueName(beniFirstName);

        Assert.assertEquals(beneficiariesObj.getRow1Name(), beniName);
        Assert.assertEquals(beneficiariesObj.getRow1Address(), beniAddress);
        Assert.assertEquals(beneficiariesObj.getRow1ContactNumber(), beniContactNumber);
        beneficiariesObj.resetFilterByValueName();

//        beneficiariesObj.setFilterByValueCOntactNo(beniContactNumber);
//
//        Assert.assertEquals(beneficiariesObj.getRow1Name(), beniName);
//        Assert.assertEquals(beneficiariesObj.getRow1Address(), beniAddress);
//        Assert.assertEquals(beneficiariesObj.getRow1ContactNumber(), beniContactNumber);

        navMenuObj.signOutfromCP();
        //homePageObj.logOutfromCP();
    }


    @Test(invocationCount = 8, description = "")
    public void myTransfersX() {
        landingPageObj.clickOnLogInBtn();
        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);
        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY,
                Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);
        homePageObj.logOutfromCP();
        landingPageObj.waitTillLogInBtnDisplaying();
    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }

}
