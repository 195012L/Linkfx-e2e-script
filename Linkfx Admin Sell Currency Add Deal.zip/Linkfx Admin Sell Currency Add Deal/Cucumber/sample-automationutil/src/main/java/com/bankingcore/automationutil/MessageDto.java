package com.bankingcore.automationutil;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class MessageDto implements Serializable {

	private static final long serialVersionUID = 1828280410086496053L;
	private String subject;
	private String templateName;
	private List<String> toAddress;
	private Map<String, Object> data;
	private List<String> bccAddress;
	private String message;
	private List<String> fileList;
}
