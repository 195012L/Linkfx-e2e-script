package com.codelantic.tests.customer;

import com.codelantic.pages.customer.*;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class MTTransferDetailsPFTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignInPF signInPFObj;
    private HomePage homePageObj;
    private MTTransferDetailsPF mtTransferDetailsPFObj;
    private MTSenderPF mtSenderPFObj;
    private MTBeneficiaryPF mtBeneficiaryPFObj;
    private MTInvoicePF mtInvoicePFObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }

            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);
            homePageObj = new HomePage(driver, commonOpObj);
            mtTransferDetailsPFObj = new MTTransferDetailsPF(driver, commonOpObj);
            mtSenderPFObj = new MTSenderPF(driver, commonOpObj);
            mtBeneficiaryPFObj = new MTBeneficiaryPF(driver, commonOpObj);
            mtInvoicePFObj = new MTInvoicePF(driver, commonOpObj);

            driver.manage().window().maximize();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }

    @Test(description = "customer landing page - sending money form - " +
            "transfer process popup form - Transfer details view - input fileds validation - recipeint country")
    public void TC2033(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.clickOnCLearRecipientCOuntryBtn();
        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        List<String> listOFNoticeVals = mtTransferDetailsPFObj.getAllNoticeDesc();
        Assert.assertTrue(listOFNoticeVals.contains(Constants.NOTIFICATION_RECIPIENT_COUNTRY_EMPTY)||
                listOFNoticeVals.contains(Constants.NOTIFICATION_RECIPIENT_COUNTRY_SELECT));
        mtTransferDetailsPFObj.clickOnContinueBtn();
    }

    @Test(description = "customer landing page - sending money form - " +
            "transfer process popup form - Transfer details view - input fileds validation - Mode of transfer")
    public void TC2034(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer("");
        mtTransferDetailsPFObj.clickOnContinueBtn();
        List<String> listOFNoticeVals = mtTransferDetailsPFObj.getAllNoticeDesc();
        Assert.assertTrue(listOFNoticeVals.contains(Constants.NOTIFICATION_MODE_OF_TRANSFER_EMPTY));
    }

    @Test(description = "customer landing page - sending money form - " +
            "transfer process popup form - Transfer details view - input fileds validation - sending amount / recieving amount")
    public void TC2035(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.setSendAmountIFtoEmpty();
        mtTransferDetailsPFObj.clickOnContinueBtn();
        List<String> listOFNoticeVals = mtTransferDetailsPFObj.getAllNoticeDesc();
        Assert.assertTrue(listOFNoticeVals.contains(Constants.NOTIFICATION_SEND_AMOUNT_EMPTY));
    }

    @Test(description = "customer landing page - sending money form - " +
            "transfer process popup form - user details - payment mode - validation")
    public void TC2084(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.clickOnContinueBtn();

        mtSenderPFObj.clickOnCLearPaymentModeBtn();
        mtSenderPFObj.clickOnContinueBtn();
        List<String> listOFNoticeVals = mtSenderPFObj.getAllNoticeDesc();
        Assert.assertTrue(listOFNoticeVals.contains(Constants.NOTIFICATION_PAYMENT_MODE_EMPTY));
    }


    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }

}
