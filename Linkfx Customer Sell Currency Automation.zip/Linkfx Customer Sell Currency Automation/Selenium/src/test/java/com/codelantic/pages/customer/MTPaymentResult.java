package com.codelantic.pages.customer;

public class MTPaymentResult {
}
