package com.codelantic.tests.transactions;

public class SAdminSenderDetailsPFTest {
}
