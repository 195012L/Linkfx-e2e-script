package com.codelantic.pages.customer;

import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import net.bytebuddy.matcher.CollectionOneToOneMatcher;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.List;

public class SignInPF extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SignInPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By usernameIF = By.id("username");
    private By passwordIF = By.id("password");
    private By loginBtn = By.xpath("//span[text()=\"Log In\"]/parent::button");
    private By avatarImg = By.xpath("//span[text()=\"B\"]/parent::nz-avatar");
    private By loader = By.cssSelector(".loader");
    private By forgotPasswordLink = By.cssSelector(".forget-password-link");
    private By forgotPasswordEmailIF = By.xpath("//input[@placeholder=\"Enter Email Address\"]");
    private By forgotPasswordSubmitBtn = By.xpath("//span[text()='Submit']/ancestor::button");
    private By forgotPasswordCancelBtn = By.cssSelector(".cancel-btn");
    private By forgotPaswwordEMailSentModal = By.xpath("//h2[text()=\"Password Reset Email Sent\"]");

    public void setUsernameIF(String username) {
        driver.findElement(usernameIF).sendKeys(username);
    }

    public void setPasswordIF(String password) {
        driver.findElement(passwordIF).sendKeys(password);
    }

    public void clickOnLogInBtn() {
        driver.findElement(loginBtn).click();
    }

    public boolean isDisplayedAvatar() {
        return driver.findElement(avatarImg).isDisplayed();
    }

    public void loginToCP(String username, String password) {
        setUsernameIF(username);
        setPasswordIF(password);
        clickOnLogInBtn();
    }

    public void clickOnFOrgotPasswordLink() {
        WebElement webElement = commonOpObj.waitUntilElementClickable(forgotPasswordLink, Constants.EXPLICIT_TIMEOUT);
        webElement.click();
    }

    public void fillTheEmailInForgotPassword(String email) {
        WebElement webElement = commonOpObj.waitUntilElementClickable(forgotPasswordEmailIF, Constants.EXPLICIT_TIMEOUT);
        webElement.sendKeys(email);
    }

    public void clickOnFOrgotPasswordSubmitBtn() {
        WebElement webElement = commonOpObj.waitUntilElementClickable(forgotPasswordSubmitBtn, Constants.EXPLICIT_TIMEOUT);
        webElement.click();
    }

    public void clickOnFOrgotPasswordCancelBtn() {
        WebElement webElement = commonOpObj.waitUntilElementClickable(forgotPasswordCancelBtn, Constants.EXPLICIT_TIMEOUT);
        webElement.click();
    }

    public boolean isForogtPasswordEMailSentSuccessMsgShowing() {
        List<WebElement> webElements = commonOpObj.waitUntilElementsvisibilityOf(forgotPaswwordEMailSentModal, Constants.EXPLICIT_TIMEOUT);
        return driver.getPageSource().contains(Constants.SIGNIN_FORGOT_PASSWORD_EMAIL_SENT_SUCESS_MSG);
    }

}
