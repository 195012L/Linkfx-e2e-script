package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.security.Key;
import java.util.List;

public class MTBeneficiaryPF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MTBeneficiaryPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    //new Beneficiary
    private By createNewBeneficiaryLink = By.partialLinkText("Beneficiary not available?");
    private By beneficiaryNameIF = By.xpath("//ng-select[@formcontrolname=\"beneficiaryFullName\"]/descendant::input");
    private By create_new_beni_firstNameIF = By.id("beneficiaryFirstName");
    private By create_new_beni_lastName = By.id("beneficiaryLastName");
    private By create_new_beni_contactNumberIF = By.id("contactNumber");
    private By create_new_beni_addressIF = By.id("address");
    //private By country = By.id("");

    //old Beneficiary
    private By selectExistingBeniLink = By.partialLinkText("Back to Search Beneficiary");
    private By select_existing_contactNumberIF = By.id("contactNumber");
    private By select_existing_addressIF = By.id("address");

    //Old Bank
    private By createNewBankLInk = By.partialLinkText("Create new Bank");
    private By select_existing_bankNameIF = By.xpath("//ng-select[@formcontrolname=\"bank\"]/descendant::input");
    private By select_existing_accountNumberIF = By.xpath("//ng-select[@formcontrolname=\"accountNumber\"]/descendant::input");
    private By select_existing_bankBranchIF = By.xpath("//ng-select[@formcontrolname=\"bankBranch\"]/descendant::input");
    private By select_existing_bankCodeIF = By.xpath("//ng-select[@formcontrolname=\"accountNumberBankCode\"]/descendant::input");
    private By select_existing_swiftCOdeIF = By.xpath("//ng-select[@formcontrolname=\"accountNumberSwiftCode\"]/descendant::input");
    private By selectedBankRadioBtn = By.name("selectedBank");

    //new Bank
    private By selectExistingBankLink = By.partialLinkText("Select Existing Bank");
    private By create_new_bank_bankNameIF = By.id("bankName");
    private By create_new_bank_accountNumberIF = By.id("accNo");
    private By create_new_bank_bankBranchIF = By.id("branchName");
    private By create_new_bank_bankCodeIF = By.id("bankCode");
    private By create_new_bank_swiftCOdeIF = By.id("swiftCode");

    private By countryDDL = By.xpath("//ng-select[@bindlabel=\"countryDto.countryName\"]/descendant::input");
    private By referenceIF = By.id("reference");
    private By contiuneBtn = By.cssSelector(".continue-btn");
    private By loader = By.cssSelector(".loader");
    private By dropDownListUI = By.cssSelector(".ng-dropdown-panel-items");

    public void clickOnCreateBeniLink(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(createNewBeneficiaryLink, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void setCreate_new_beni_firstNameIF(String fn){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_beni_firstNameIF, Constants.EXPLICIT_TIMEOUT).sendKeys(fn);
        }
    }

    public void setCreate_new_beni_lastName(String ln){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_beni_lastName, Constants.EXPLICIT_TIMEOUT).sendKeys(ln);
        }
    }

    public void setCreate_new_beni_contactNumberIF(String n){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_beni_contactNumberIF, Constants.EXPLICIT_TIMEOUT).sendKeys(n);
        }
    }

    public void setCreate_new_beni_addressIF(String adrs){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_beni_addressIF, Constants.EXPLICIT_TIMEOUT).sendKeys(adrs);
        }
    }

    public void clickOnselectExistingBeniLink(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(selectExistingBeniLink, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void clickOncreateNewBankLInk(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(createNewBankLInk, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void setCreate_new_bank_bankNameIF(String bn){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_bank_bankNameIF, Constants.EXPLICIT_TIMEOUT).sendKeys(bn);
        }
    }

    public void setCreate_new_bank_accountNumberIF(String bacc){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_bank_accountNumberIF, Constants.EXPLICIT_TIMEOUT).sendKeys(bacc);
        }
    }

    public void setCreate_new_bank_bankBranchIF(String bb){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_bank_bankBranchIF, Constants.EXPLICIT_TIMEOUT).sendKeys(bb);
        }
    }

    public void setCreate_new_bank_bankCodeIF(String bc){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_bank_bankCodeIF, Constants.EXPLICIT_TIMEOUT).sendKeys(bc);
        }
    }

    public void setCreate_new_bank_swiftCOdeIF(String sft){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(create_new_bank_swiftCOdeIF, Constants.EXPLICIT_TIMEOUT).sendKeys(sft);
        }
    }

    public void clickOnselectExistingBankLink(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(selectExistingBankLink, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void setselect_existing_bankNameIF(String bn){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(select_existing_bankNameIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(bn);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setSelect_existing_accountNumberIF(String acc){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(select_existing_accountNumberIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(acc);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setSelect_existing_bankBranchIF(String bb){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(select_existing_bankBranchIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(bb);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setSelect_existing_bankCodeIF(String bc){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(select_existing_bankCodeIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(bc);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setSelect_existing_swiftCOdeIF(String sft){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(select_existing_swiftCOdeIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(sft);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setBeneficiaryNameIF(String bName){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(beneficiaryNameIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            webElement.sendKeys(bName);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setCountryDDL(String cntry){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(countryDDL, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(cntry);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setSelectedBankRadioBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            List<WebElement> webElement = commonOpObj.waitUntilElementsvisibilityOf(selectedBankRadioBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.get(0).click();
        }
    }

    public void setReference(String ref) {
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            driver.findElement(referenceIF).sendKeys(ref);
        }
    }

    public void clickOnContinueBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
           commonOpObj.waitUntilElementClickable(contiuneBtn, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void fillBeneficiaryDetailsIFsWithValueSet1(String bName, String ref){
        setBeneficiaryNameIF(bName);
        setReference(ref);
        clickOnContinueBtn();
    }

    public void fillBenificiaryNewBeniNewBank(String fn, String ln, String cn, String adrs, String cntry, String bn,
                                              String bacc, String bb, String bc, String sft){

        clickOnCreateBeniLink();

        setCountryDDL(cntry);
        setCreate_new_beni_firstNameIF(fn);
        setCreate_new_beni_lastName(ln);
        setCreate_new_beni_contactNumberIF(cn);
        setCreate_new_beni_addressIF(adrs);

        clickOncreateNewBankLInk();

        setCreate_new_bank_bankNameIF(bn);
        setCreate_new_bank_accountNumberIF(bacc);
        setCreate_new_bank_bankBranchIF(bb);
        //setCreate_new_bank_bankCodeIF();
        //setCreate_new_bank_swiftCOdeIF();

    }

    public void fillBenificiaryNewBeniOldBank(){

    }

    public void fillBenificiaryOldBeniNewBank(){



    }

    public void fillBenificiaryOldBeniOldBank(String beniName, String cntry){
        setCountryDDL(cntry);
        setBeneficiaryNameIF(beniName);
        setSelectedBankRadioBtn();
    }
}
