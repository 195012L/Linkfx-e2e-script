package com.Linkfx.automation.seleniumpages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;

import com.Linkfx.automation.BasePage;
import com.Linkfx.automation.ConfigFileReader;
import com.Linkfx.datatables.AddUser;
import com.Linkfx.datatables.SellCurrency;
import com.Linkfx.utils.CommonOp;
import com.Linkfx.utils.Constants;
import com.paulhammant.ngwebdriver.NgWebDriver;


import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomerSellCurrency extends BasePage {
	CommonOp commonOpObj = null;
	ConfigFileReader configFileReader = null;
	
	By loginIF = By.xpath("//body/app-root[1]/app-login[1]/div[1]/form[1]/div[1]/div[2]/div[1]/nz-form-item[1]/nz-form-control[1]/div[1]/div[1]/nz-input-group[1]/input[1]");
	By userbutton = By.xpath("//li[@ng-reflect-router-link='user-management']");
	By Adduserbutton = By.xpath("//button[@ng-reflect-nz-type='primary']");
	By Firstname = By.xpath("//input[@ng-reflect-name='firstName']");
	
	public void launchChromeBrowser() {
		
		driver.manage().window().maximize();
		configFileReader = new ConfigFileReader();

		ChromeOptions options = new ChromeOptions();
	
		options.addArguments("disable-infobars");
		JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
		NgWebDriver ngDriver = new NgWebDriver(jsDriver);

		driver.get(configFileReader.getApplicationUrl());
		ngDriver.waitForAngularRequestsToFinish();
		//log.info("Opened Home Page");
		commonOpObj = new CommonOp(driver);
	}

	
	public void loginAgain(List<AddUser> addUser) {
		
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		WebElement login = driver.findElement(loginIF);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		login.click();
		
		
		for (AddUser addUser1 : addUser){
			commonOpObj.Sleep(Constants.WAITING_TIME_HIGH);
			WebElement email = driver.findElement(By.xpath("//body/app-root[1]/app-login[1]/div[1]/form[1]/div[1]/div[2]/div[1]/nz-form-item[1]/nz-form-control[1]/div[1]/div[1]/nz-input-group[1]/input[1]"));
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			email.sendKeys(addUser1.getEmail());
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);

			WebElement password = driver.findElement(By.xpath("//body/app-root[1]/app-login[1]/div[1]/form[1]/div[1]/div[3]/div[1]/nz-form-item[1]/nz-form-control[1]/div[1]/div[1]/nz-input-group[1]/input[1]"));
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			password.sendKeys(addUser1.getPassword());
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			
			driver.findElement(By.xpath("//body/app-root[1]/app-login[1]/div[1]/form[1]/div[1]/div[4]/div[1]/nz-form-item[1]/div[1]/label[1]/span[1]/input[1]")).click();
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);

			driver.findElement(By.xpath("//body/app-root[1]/app-login[1]/div[1]/form[1]/div[1]/div[5]/div[1]/button[1]")).click();
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
	}		
			
		public void sellCurrency() 
		{
			
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/p[1]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        
		}
		public void sellCurrency1() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[2]/nz-select[1]/nz-select-top-control[1]/nz-select-search[1]/input[1]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		} 
		public void sellCurrency2() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        driver.findElement(By.xpath("//div[contains(text(),'Paddington')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		  
		public void sellCurrency3() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
				driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/nz-select[1]/nz-select-top-control[1]")).click();
				commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        driver.findElement(By.xpath("//div[contains(text(),'AUD')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}      
		public void sellCurrency4(List<SellCurrency> sellCurrency) 
		{
			for (SellCurrency sellCurrencyItem1 : sellCurrency) 
			{ 
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);        
		        WebElement amount = driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]"));
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		        amount.sendKeys(sellCurrencyItem1.getAmount());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			}
		}
		
		public void sellCurrency6() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
				driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/p[1]/img[1]")).click();
				commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        driver.findElement(By.xpath("//span[contains(text(),'Denomination')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}       
		public void sellCurrency7() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);   
		        driver.findElement(By.xpath("//button[contains(text(),'OK')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		public void sellCurrency8() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[1]/form[1]/div[1]/div[3]/div[1]/div[1]/div[2]/button[1]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		public void sellCurrency9() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("//button[contains(text(),'Complete deal')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		public void sellCurrency12() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-add-transaction/div[3]/app-complete-deal/div/div/div/div/div[5]/button")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		public void sellCurrency10() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("//span[contains(text(),'Total Amount')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		public void sellCurrency11() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-add-transaction[1]/div[4]/div[1]/app-transaction-card[1]/div[1]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		}
		
		public void sellCurrency13() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
				driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal-container[1]/div[1]/div[1]/div[1]/app-parcel-and-notes[1]/div[1]/form[1]/div[1]/div[1]/div[1]/label[1]/span[1]/input[1]")).click();
				commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		            
		}
		public void sellCurrency14() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("//button[contains(text(),'ok')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		            
		}
		
		public void sellCurrency15() 
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);  
		        driver.findElement(By.xpath("//span[contains(text(),'Deal Reference number')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		            
		}
		public void sellCurrencies(List<SellCurrency> sellCurrency) 
		{
			for (SellCurrency sellCurrencyItem : sellCurrency) 
			{   
				
				commonOpObj = new CommonOp(driver);
				commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
				
				driver.findElement(By.xpath("//p[contains(text(),'sell currency')]")).click();
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
				
			}
		}
		public void sellCurrencies1(List<SellCurrency> sellCurrency) 
		{
			for (SellCurrency currency : sellCurrency) 
			{
				
				commonOpObj = new CommonOp(driver);
				commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
				
				 WebElement value = driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal-container[1]/div[1]/div[1]/div[1]/app-denomination-modal[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]"));
			     value.sendKeys(currency.getValue());
			     commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
				
			}
		}
		public void sellCurrencies2(List<SellCurrency> sellCurrency2) 
		{
			for (SellCurrency sellCurrencyItem : sellCurrency2) 
			{
				commonOpObj = new CommonOp(driver);
				commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
				
				    WebElement bagNumbers = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal-container/div/div/div/app-parcel-and-notes/div/form/div/div/input"));
			        bagNumbers.sendKeys(sellCurrencyItem.getBagNumbers());
			        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			        
			        WebElement reference= driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal-container[1]/div[1]/div[1]/div[1]/app-parcel-and-notes[1]/div[1]/form[1]/div[1]/div[1]/textarea[1]"));
			        reference.sendKeys(sellCurrencyItem.getReference());
			        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			        
			}
		}

	}


