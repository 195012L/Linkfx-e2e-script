package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

public class MTInvoicePF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MTInvoicePF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By notification = By.tagName("nz-notification-container");
    private By closeBtn = By.cssSelector(".ant-modal-close-x");
    private By confirmBtn = By.xpath("//span[text()=\"Confirm Transaction\"]/ancestor::button");
    private By senderNameIF = By.id("senderName");
    private By transferredAmountIF = By.id("transferredAmount");
    private By beneficiaryNameIF = By.id("beneficiaryName");
    private By modeOfServiceIF = By.id("modeOfService");
    private By receivedAmountIF = By.id("receivedAmount");
    private By invoiceIF = By.id("invoice");
    private By dateIF = By.id("date");
    private By loader = By.cssSelector(".loader");
    private By closeNotification = By.cssSelector(".ant-notification-notice-close");
    private By notificationDesccription = By.cssSelector(".ant-notification-notice-description");

    public void clickOnCOnfirmBtn(){
        if (commonOpObj.waitUntilElementInvisibilityOf(notification, Constants.EXPLICIT_TIMEOUT)) {
            commonOpObj.waitUntilElementClickable(confirmBtn, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void clickOncloseBtn(){
        if (commonOpObj.waitUntilElementInvisibilityOf(notification, Constants.EXPLICIT_TIMEOUT)) {
            driver.findElement(closeBtn).click();
        }
    }

    public String confirmAndCLoseTheTransaction(){
        String notiDesc = getnotificationDesccription();
        clickOncloseNotification();
        clickOnCOnfirmBtn();
        return notiDesc;
    }

    public String getsenderNameIF(){
        return driver.findElement(senderNameIF).getAttribute("value");
    }

    public String gettransferredAmountIF(){
        return driver.findElement(transferredAmountIF).getAttribute("value");
    }

    public String getbeneficiaryNameIF(){
        return driver.findElement(beneficiaryNameIF).getAttribute("value");
    }

    public String getmodeOfServiceIF(){
        return driver.findElement(modeOfServiceIF).getAttribute("value");
    }

    public String getreceivedAmountIF(){
        return driver.findElement(receivedAmountIF).getAttribute("value");
    }

    public String getinvoiceIF(){
        return driver.findElement(invoiceIF).getAttribute("value");
    }

    public String getdateIF(){
        return driver.findElement(dateIF).getAttribute("value");
    }

    public void clickOncloseNotification(){
        commonOpObj.closeNotifications(loader, closeNotification);
    }

    public String getnotificationDesccription(){
        return commonOpObj.getNotificationDesc(loader, notificationDesccription);
    }
}


