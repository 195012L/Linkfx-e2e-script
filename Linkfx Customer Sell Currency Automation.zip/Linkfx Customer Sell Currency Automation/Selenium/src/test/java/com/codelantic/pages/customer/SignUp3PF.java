package com.codelantic.pages.customer;

import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SignUp3PF extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SignUp3PF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By userName = By.id("idCheckConfirmationFormUserName");
    private By firstName = By.id("idCheckConfirmationFormFirstName");
    private By lastName = By.id("idCheckConfirmationFormLastName");
    private By dob = By.id("idCheckConfirmationFormDateOfBirth");
    private By placeOfBirth = By.id("idCheckConfirmationFormPlaceOfBirth");
    private By email = By.id("idCheckConfirmationFormEmail");
    private By contactNumber = By.id("idCheckConfirmationFormContactNumber");
    private By address = By.id("idCheckConfirmationFormAddressLineOne");
    private By postCode = By.id("idCheckConfirmationFormPostCode");
    private By country = By.xpath("//ng-select[@id=\"idCheckConfirmationFormCountry\"]/descendant::input");
    //.................................
    private By idType = By.id("");
    //..................................
    private By idNUmber = By.id("idCheckConfirmationFormIdentificationNumber");
    private By idExpireNo = By.id("idCheckConfirmationFormIdentificationExpireDate");
    private By summaryText = By.cssSelector(".summary-text");
    private By continueBtn = By.cssSelector(".continue-btn");
    private By cancelBtn = By.cssSelector("cancel-btn");
    private By loader = By.cssSelector(".loader");

    public String getUserName(){
        return driver.findElement(userName).getAttribute("value");
    }

    public String getfirstName(){
        return driver.findElement(firstName).getAttribute("value");
    }

    public String getlastName(){
        return driver.findElement(lastName).getAttribute("value");
    }

    public String getdob(){
        return driver.findElement(dob).getAttribute("value");
    }

    public String getplaceOfBirth(){
        return driver.findElement(placeOfBirth).getAttribute("value");
    }

    public String getemail(){
        return driver.findElement(email).getAttribute("value");
    }

    public String getcontactNumber(){
        return driver.findElement(contactNumber).getAttribute("value");
    }

    public String getaddress(){
        return driver.findElement(address).getAttribute("value");
    }

    public String getpostCode(){
        return driver.findElement(postCode).getAttribute("value");
    }

    public String getcountry(){
        return driver.findElement(country).getAttribute("value");
    }

    public String getIDtype(){
        return driver.findElement(idType).getAttribute("value");
    }

    public String getidNUmber(){
        return driver.findElement(idNUmber).getAttribute("value");
    }

    public String getidExpireNo(){
        return driver.findElement(idExpireNo).getAttribute("value");
    }

    public void clickOnCOntinueBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(continueBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnCancelBtn(){
        driver.findElement(cancelBtn).click();
    }

    public String getSummaryText(){
        return driver.findElement(summaryText).getText();
    }
}
