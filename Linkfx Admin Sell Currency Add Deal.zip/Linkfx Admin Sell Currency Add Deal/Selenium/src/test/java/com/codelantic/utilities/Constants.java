package com.codelantic.utilities;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Constants {

    public static final String CHROME_DRIVER_WIN    = "webdriver.chrome.driver.win";
    public static final String FIREFOX_DRIVER_WIN   = "webdriver.gecko.driver.win";
    public static final String IE_DRIVER_WIN        = "webdriver.ie.driver.win";
    public static final String EDGE_DRIVER_WIN      = "webdriver.edge.driver.win";

    public static final String CHROME_DRIVER_MAC    = "webdriver.chrome.driver.mac";
    public static final String FIREFOX_DRIVER_MAC   = "webdriver.gecko.driver.mac";

    public static final long EXPLICIT_TIMEOUT = 5;
    public static final long EXPLICIT_TIMEOUT_FOR_DROP_DOWNS = 5;
    public static final long TIMEOUT_FOR_DROP_DOWNS = 500;

    public static final String CP_USERNAME = "baghya@codelantic.com";
    public static final String CP_PASSWORD = "123Qwe@#";

    public static final String SIGNUP1_FN           = "UAF101";
    public static final String SIGNUP1_LN           = "UAL101";
    public static final String SIGNUP1_CONTACTNO    = "123456";
    public static final String SIGNUP1_UN           = "UAU501@code.com";
    public static final String SIGNUP1_PSWD         = "123Qwe@#";
    public static final String SIGNUP1_CNFM_PSWD    = "123Qwe@#";
    public static final String SIGNUP1_ADDRS        = "mystreet";
    public static final String SIGNUP1_POSTCODE     = "00600";
    public static final String SIGNUP1_COUNTRY      = "Thailand";

    public static final String SIGNUP2_DOB          = "01-09-1991";
    public static final String SIGNUP2_PLACE        = "Colombo";
    public static final String SIGNUP2_IDTYPE       = "Driving licence";
    public static final String SIGNUP2_IDNO         = "1234567890";
    public static final String SIGNUP2_IDEXPIRE     = "02-01-2030";
    public static final String SIGNUP2_FRONTPATH    = "E:\\CodeLantic\\MONEX\\AML\\front.png";
    public static final String SIGNUP2_BACKPATH     = "E:\\CodeLantic\\MONEX\\AML\\back.png";
    public static final String SIGNUP2_SECTYPE      = "Bank Statement";
    public static final String SIGNUP2_SECPATH      = "E:\\CodeLantic\\MONEX\\AML\\front.png";

    public static final String SIGNUP3_SUMMARYTEXT  = "Here is a summary of your entered information. If all details are enterd correctly, click continue to proceed.";

    public static final String SIGNUP_USER_CREATED_CONGRATS_MSG = "Your registration successful, You will receive the approval email soon...";

    public static final String emailAddress = "baghya@codelantic.com";

    public static final String SIGNIN_FORGOT_PASSWORD_EMAIL_SENT_SUCESS_MSG = "Password Reset Email Sent";

    public static final List<String> ID_TYPES_LIST = Arrays.asList("Passport","Driving licence","Insurance card");
    public static final List<String> SEC_ID_TYPES_LIST = Arrays.asList("Utility Bills","Council Tax Bill","Bank Statement");

    public static final String MOT_BANK_DEPOSIT     = "Bank Deposit";
    public static final String MOT_CASH_DEPOSIT     = "Cash Pickup";

    public static final String PAYMODE_BANK_DEPOSIT     = "Bank Deposit";
    public static final String PAYMODE_DEBIT_CARD       = "Debit Card";

    public static final String MT_SET1_SENDER_FULL_NAME     = "mfx mlx";
    public static final String MT_SET1_SENDER_FIRST_NAME    = "mfx";
    public static final String MT_SET1_SENDER_LAST_NAME     = "mlx";
    public static final String MT_SET1_SENDER_TEL_LAND      = "1234456";
    public static final String MT_SET1_SENDER_TEL_MOBILE    = "1234456";
    public static final String MT_SET1_SENDER_EMAIL         = "baghya@codelantic.com";
    public static final String MT_SET1_SENDER_ADRS          = "mystreet";
    public static final String MT_SET1_SENDER_ID_TYPE       = "Passport";
    public static final String MT_SET1_SENDER_ID_NO         = "B15440273232131";
    public static final String MT_SET1_SENDER_PAY_MODE      = "Bank Deposit";

    public static final String MT_SET1_SENDING_CNTRY        = "GBP";
    public static final String MT_SET1_RECIEVING_CNTRY      = "THB";
    public static final String MT_SET1_SENDING_AMOUNT       = "10";
    public static final String MT_SET1_RECIEVING_AMOUNT     = "100.00";
    public static final String MT_SET1_BENI_NAME            = "ben ben";
    public static final String MT_SET1_RECIPIENT_CNTRY      = "Thailand";

    public static final String NEW_BENI_FN              = "bb115";
    public static final String NEW_BENI_lN              = "mm115";
    public static final String NEW_BENI_cN              = "1234568";
    public static final String NEW_BENI_ADRS            = "mystreet";
    public static final String NEW_BENI_FULL_NAME       =  NEW_BENI_FN + " " + NEW_BENI_lN;

    public static final String NEW_BANK_BN      = "TEST BANK";
    public static final String NEW_BANK_BACC    = "1111111111111111111111";
    public static final String NEW_BANK_BB      = "TEST BRANCH";
    public static final String NEW_BANK_BC      = "12345QWERT";
    public static final String NEW_BANK_SFT     = "QWERT12345";

    public static final String MT_SET1_REF      = "Testing Reference";

    public static final String MT_ACC_DETAILS_PAYMENT_NOTE              = "Please make a payment of";
    public static final String MT_INVOICE_SUCCESS_NOTIFICATION          = "Save transaction successfully";
    public static final String MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION  = "Successfully Completed Transaction";

    public static final String TRANSACTIONS_STATUS_ACCEPTED     = "Accepted";
    public static final String TRANSACTIONS_STATUS_CREATED      = "Created";

    public static final String NOTIFICATION_RECIPIENT_COUNTRY_EMPTY         = "Recipient Country cannot be empty";
    public static final String NOTIFICATION_RECIPIENT_COUNTRY_SELECT        = "Recipient Country must be Selected";
    public static final String NOTIFICATION_MODE_OF_TRANSFER_EMPTY          = "Mode of Transfer cannot be empty";
    public static final String NOTIFICATION_SEND_AMOUNT_EMPTY               = "Send Amount cannot be empty";
    public static final String NOTIFICATION_PAYMENT_MODE_EMPTY                   = "Payment Modes cannot be empty";
    public static final String NOTIFICATION_SEND_AMOUNT_EMPTY_N                   = "Minimum sending Amount is 10.00";

}
