package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class MTCardPayment {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MTCardPayment(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By cardNumber = By.name("card.number");
    private By cardExpiryDate = By.xpath("//input[@aria-label=\"Expiry Date\"]");
    private By cardCVV = By.name("card.cvv");
    private By cardHolderName = By.name("card.holder");
    private By cardBrand = By.name("paymentBrand");
    private By cardPayBtn = By.xpath("//button[text()=\"Pay now\"]");
    private By loader = By.cssSelector(".loader");
    private By closeBtn = By.xpath("//button[text()=\"Close\"]");
    private By closeNotification = By.cssSelector(".ant-notification-notice-close");

    public void setCardNumber(String number){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cardNumber, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(number);
        }
    }

    public void setCardExpiryDate(String date){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cardExpiryDate, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(date);
        }
    }

    public void setCardHolderName(String name){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cardHolderName, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(name);
        }
    }

    public void setCardCVV(String cvv){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cardCVV, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(cvv);
        }
    }

    public void clickOnPayBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cardPayBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void waitUnillPaymentProcessAppeared(){
        commonOpObj.waitUntilElementvisibilityOf(cardNumber, 3000);
    }

    public void setDebitCardDetailsForVISAandPay(String brand, String number, String expiryDate, String cvv, String holderName){

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        waitUnillPaymentProcessAppeared();

        setCardNumber(number);
        setCardExpiryDate(expiryDate);
        setCardHolderName(holderName);
        setCardCVV(cvv);
        clickOnPayBtn();
        clickOnCLoseBtn();

    }

    public void clickOnCLoseBtn(){
        try {
            Thread.sleep(10000);
            WebElement webElement = commonOpObj.waitUntilElementvisibilityOf(closeBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
