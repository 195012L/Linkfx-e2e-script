package com.Linkfxs.automation.stepdefinition;

import java.util.List;

import com.Linkfx.automation.seleniumpages.CustomerSellCurrency;
import com.Linkfx.datatables.AddUser;
import com.Linkfx.datatables.SellCurrency;
import com.Linkfx.utils.CommonOp;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;

	public class SellCurrencyProcess {
	CustomerSellCurrency simpleLoginpage = new CustomerSellCurrency();
	
	private CommonOp commonOpObj = null;
	@Given("^User Login Again$")
	public void User_Login_Again(List<AddUser> addUser) throws Exception 
	{
		simpleLoginpage.launchChromeBrowser();
		simpleLoginpage.loginAgain(addUser);	
	}
	@Given("^Redirect to home page URl$")
	public void Redirect_to_home_page_URl(List<SellCurrency> sellCurrency) throws Exception 
	{
		simpleLoginpage.sellCurrencies(sellCurrency);
	}
	@When("^I Click on sell currency button$")
	public void I_Click_on_sell_currency_button()
	{
		simpleLoginpage.sellCurrency();
	}
	@Then("^check Company name$")
	public void check_Company_name()
	{
		simpleLoginpage.sellCurrency1();
	}
	@When("^Select Branch from Dropdown$")
	public void Select_Branch_from_Dropdown()
	{
		simpleLoginpage.sellCurrency2();
	}
	@And("^Select the Sell currency from the drop down$")
	public void Select_the_Sell_currency_from_the_drop_down()
	{
		simpleLoginpage.sellCurrency3();
	}
	@When("^Type the  Amount$")
	public void Type_the_Amount(List<SellCurrency> sellCurrency)
	{
		simpleLoginpage.sellCurrency4(sellCurrency);
	}
	@And("^Click on Denomination$")
	public void Click_on_Denomination()
	{
		simpleLoginpage.sellCurrency6();
	}
	@When("^Pass the Value in Denomination field$")
	public void pass_the_Value_in_Denomination_field(List<SellCurrency> sellCurrency) throws Exception 
	{
	    simpleLoginpage.sellCurrencies1(sellCurrency); 
	}
	
	@And("^Click on ok$")
	public void Click_on_ok()
	{
		simpleLoginpage.sellCurrency7();
	}
	@When("^Click Add currency$")
	public void Click_Add_currency()
	{
		simpleLoginpage.sellCurrency8();
	}
	@And("^Click on Complete deal$")
	public void Click_on_Complete_deal()
	{
		simpleLoginpage.sellCurrency9();
	}
	@Then("^Check the Total Amount$")
	public void Check_the_Total_Amount()
	{
		simpleLoginpage.sellCurrency10();
	}
	@And("^Check the Transaction breakdown$")
	public void Check_the_Transaction_breakdown()
	{
		simpleLoginpage.sellCurrency11();
	}
	@And("^Click on Complete Deal$")
	public void click_on_Complete_Deal()
	{
		simpleLoginpage.sellCurrency12();
	}
	
	@When("^Give the Couriers BAG Numbers and Your Reference$")
	public void give_the_Couriers_BAG_Numbers_and_Your_Reference(List<SellCurrency> sellCurrency2)throws Exception
	{
		simpleLoginpage.sellCurrencies2(sellCurrency2);
	}
	@When("^Click on agree to the terms and condition$")
	public void click_on_agree_to_the_terms_and_condition()
	{
		simpleLoginpage.sellCurrency13();
	}
	@When("^Click on OK$")
	public void Click_on_OK()
	{
		simpleLoginpage.sellCurrency14();
	}
	
	@Then("^check submitted successfully popUp Box$")
	public void check_submitted_successfully_popUp_Box()
	{
		simpleLoginpage.sellCurrency15();
	}
	

}
