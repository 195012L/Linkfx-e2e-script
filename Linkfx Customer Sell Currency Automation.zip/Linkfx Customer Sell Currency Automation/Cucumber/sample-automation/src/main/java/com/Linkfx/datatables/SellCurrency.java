package com.Linkfx.datatables;

public class SellCurrency {
   
    private String password;
    private String value;
    private String email;
    private String bagNumbers;
    private String reference;
    private String amount;

    // Getters and Setters
    
    
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
    public String getBagNumbers() {
        return bagNumbers;
    }

    public void setBagNumbers(String bagNumbers) {
        this.bagNumbers = bagNumbers;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
