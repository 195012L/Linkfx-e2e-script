package com.codelantic.tests.transactions;

import com.codelantic.pages.transactions.LoginPage;
import com.codelantic.pages.transactions.SATransferDetailsPF;
import com.codelantic.pages.transactions.SAdminHomePage;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class TransfersTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }
            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
        driver.manage().window().maximize();
    }

    @Test
    public void testMakeTransfer(){

        String username = "user@code.com";
        String password = "Test_1user";
        String saTransferDetailsPFSendingCountry = "United Kingdom";
        String saTransferDetailsPFRecipientCounrty = "Thailand";
        String saTransferDetailsPFSendAmount = "100";
        //String saTransferDetailsPFRecievedAmount = "100";
        String saTransferDetailsPFmodeOFModeOFTransfer = "Bank Deposit";
        String saTransferDetailsPFTransferFee = "Fixed";

        LoginPage loginPageObj = new LoginPage(driver, commonOpObj);
        loginPageObj.logInToSAPortal(username, password);

        SAdminHomePage sAdminHomePageObj  = new SAdminHomePage(driver, commonOpObj);
        sAdminHomePageObj.CLickOnMAkeTransfer();

        SATransferDetailsPF saTransferDetailsPFObj = new SATransferDetailsPF(driver, commonOpObj);
        saTransferDetailsPFObj.fillTransferDetails(saTransferDetailsPFSendingCountry,
                saTransferDetailsPFRecipientCounrty,saTransferDetailsPFSendAmount, "",
                saTransferDetailsPFmodeOFModeOFTransfer, saTransferDetailsPFTransferFee);



    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            driver.quit();
        }
    }

}
