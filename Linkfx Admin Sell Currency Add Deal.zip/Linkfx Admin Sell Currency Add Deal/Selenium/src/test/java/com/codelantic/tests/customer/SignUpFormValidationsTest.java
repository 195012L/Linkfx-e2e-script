package com.codelantic.tests.customer;

import com.codelantic.pages.customer.*;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class SignUpFormValidationsTest extends BaseTest {
    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignUpPF signUpPFObj;
    private SignUp2PF signUp2PFObj;
    private SignUp3PF signUp3PFObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }
            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signUpPFObj = new SignUpPF(driver, commonOpObj);
            signUp2PFObj =  new SignUp2PF(driver, commonOpObj);
            signUp3PFObj = new SignUp3PF(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }


    @Test(description = "customer landing page - signup form - validate the input field - first name")
    public void TC2058(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues("", Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("First Name cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - last name")
    public void TC2059(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, "", Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Last Name cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - user name")
    public void TC2060(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                "", Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("User Name cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - password")
    public void TC2061(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, "", Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Password cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - confirm password")
    public void TC2062(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, "",
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Confirm Password cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - password validation (No matching)")
    public void TC2063_TC2064(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, "123Qwe@#", "123Qwe@#$",
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Confirm password not matched"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - Contact Number")
    public void TC2065_TC2066(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, "",
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Contact Number cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - Address")
    public void TC2067(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                "", Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Address cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - Post Code")
    public void TC2068(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, "", Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Post Code cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - Country")
    public void TC2069(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, "");
        signUpPFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Country cannot be empty"));
        //signUpPFObj.closeNotifications();
    }

    @Test(description = "customer landing page - signup form - validate the input field - Select ID Type")
    public void TC2070_TC2071(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE, "" , Constants.SIGNUP2_IDNO,
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("ID Type cannot be empty"));
    }

    @Test(description = "customer landing page - signup form - validate the input field - Select ID Type -types")
    public void TC2072(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.clickOnIDtype();
        List<String> listOfIDtypes = signUp2PFObj.getIDtypes();
        Assert.assertFalse(listOfIDtypes.isEmpty());
        Assert.assertTrue(Constants.ID_TYPES_LIST.containsAll(listOfIDtypes));
    }

    @Test(description = "customer landing page - signup form - validate the input field - Date of Birth")
    public void TC2074(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues("", Constants.SIGNUP2_PLACE, Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Date of Birth cannot be empty"));
    }

    @Test(description = "customer landing page - signup form - validate the input field - Place of Birth")
    public void TC2076(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, "", Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Place of Birth cannot be empty"));
    }

    @Test(description = "customer landing page - signup form - validate the input field - Identification Number")
    public void TC2077(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE, Constants.SIGNUP2_IDTYPE , "",
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Identification Number cannot be empty"));
    }

    @Test(description = "customer landing page - signup form - validate the input field - Identification Expire Date")
    public void TC2078(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE, Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
                "", Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        Assert.assertTrue(signUpPFObj.getNotificationDesc().contains("Identification Expire Date cannot be empty"));
    }

    @Test(description = "customer landing page - signup form - ID Verification - image upload")
    public void TC2080(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE, Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();
        Assert.assertEquals(signUp3PFObj.getSummaryText(), Constants.SIGNUP3_SUMMARYTEXT);
    }

    @Test(description = "customer landing page - signup form - ID Verification - secondary ID type")
    public void TC2081(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.clickOnSecIDtype();
        List<String> listOfSecIDtypes = signUp2PFObj.getSecIDtypes();
        Assert.assertFalse(listOfSecIDtypes.isEmpty());
        Assert.assertTrue(Constants.SEC_ID_TYPES_LIST.containsAll(listOfSecIDtypes));
    }

    @Test
    public void signUpSavingDetailsValidationTest(){
        landingPageObj.clickOnSignUpBtn();
        signUpPFObj.fillSignUpPFwithValues(Constants.SIGNUP1_FN, Constants.SIGNUP1_LN, Constants.SIGNUP1_CONTACTNO,
                Constants.SIGNUP1_UN, Constants.SIGNUP1_PSWD, Constants.SIGNUP1_CNFM_PSWD,
                Constants.SIGNUP1_ADDRS, Constants.SIGNUP1_POSTCODE, Constants.SIGNUP1_COUNTRY);
        signUpPFObj.clickOnContinueBtn();
        signUp2PFObj.fillSignUp2PFwithValues(Constants.SIGNUP2_DOB, Constants.SIGNUP2_PLACE,Constants.SIGNUP2_IDTYPE , Constants.SIGNUP2_IDNO,
                Constants.SIGNUP2_IDEXPIRE, Constants.SIGNUP2_FRONTPATH, Constants.SIGNUP2_BACKPATH,
                Constants.SIGNUP2_SECTYPE, Constants.SIGNUP2_SECPATH);
        signUp2PFObj.clickOnContinueBtn();

        Assert.assertEquals(signUp3PFObj.getfirstName(),Constants.SIGNUP1_FN);
        Assert.assertEquals(signUp3PFObj.getlastName(), Constants.SIGNUP1_LN);
        Assert.assertEquals(signUp3PFObj.getcontactNumber(), Constants.SIGNUP1_CONTACTNO);
        Assert.assertEquals(signUp3PFObj.getUserName(), Constants.SIGNUP1_UN);
        Assert.assertEquals(signUp3PFObj.getaddress(), Constants.SIGNUP1_ADDRS);
        Assert.assertEquals(signUp3PFObj.getpostCode(), Constants.SIGNUP1_POSTCODE);
        Assert.assertEquals(signUp3PFObj.getplaceOfBirth(), Constants.SIGNUP2_PLACE);
        Assert.assertEquals(signUp3PFObj.getidNUmber(), Constants.SIGNUP2_IDNO);
        //Assert.assertEquals(signUp3PFObj.getcountry(), Constants.SIGNUP1_COUNTRY);
        //Assert.assertEquals(signUp3PFObj.getdob(), Constants.SIGNUP2_DOB);
        //Assert.assertEquals(signUp3PFObj.getIDtype(), Constants.SIGNUP2_IDTYPE);
        //Assert.assertEquals(signUp3PFObj.getidExpireNo(), Constants.SIGNUP2_IDEXPIRE);

    }


    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }

}
