package com.codelantic.tests.customer;

import com.codelantic.pages.customer.HomePage;
import com.codelantic.pages.customer.LandingPage;
import com.codelantic.pages.customer.SignInPF;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class SignInPFTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignInPF signInPFObj;
    private HomePage homepageObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }
            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);
            homepageObj = new HomePage(driver, commonOpObj);

            driver.manage().window().maximize();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }

    @Test(description = "customer sign in to portal")
    public void TC2002_TC2023(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        Assert.assertTrue(signInPFObj.isDisplayedAvatar());
    }

    @Test(description = "customer sign in to portal - forget your password")
    public void TC2003(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.clickOnFOrgotPasswordLink();
        signInPFObj.fillTheEmailInForgotPassword(Constants.emailAddress);
        signInPFObj.clickOnFOrgotPasswordSubmitBtn();
        Assert.assertTrue(signInPFObj.isForogtPasswordEMailSentSuccessMsgShowing());
    }

    @Test()
    public void SignInSignOut(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);
        homepageObj.logOutfromCP();
    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }

}
