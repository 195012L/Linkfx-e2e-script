package com.codelantic.tests.customer;

import com.codelantic.pages.customer.*;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class SettingsPageTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private HomePage homePageObj;
    private SignInPF signInPFObj;
    private SettingsPage settingsPageObj;
    private NavMenu navmenuObj;
    private HomePage homepageObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }
            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            homePageObj = new HomePage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);
            settingsPageObj = new SettingsPage(driver, commonOpObj);
            navmenuObj = new NavMenu(driver, commonOpObj);
            homepageObj = new HomePage(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }

    @Test(description = "Customer portal - settings - change password")
    public void TC2301(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        homepageObj.clickOnProfileBtn();
        homepageObj.clickOnsettingMEnuItemLink();
        settingsPageObj.setCurrentPasswordIF(Constants.CP_PASSWORD);
        settingsPageObj.setNewPasswordIF(Constants.CP_PASSWORD);
        settingsPageObj.clickOnSaveProfileDetailsBtn();
        Assert.assertTrue(settingsPageObj.getNotificationDesc().equalsIgnoreCase("Details have been updated successfully"));
    }

    @Test(description = "Customer portal - settings - try to change First Name")
    public void TC2302(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        homepageObj.clickOnProfileBtn();
        homepageObj.clickOnsettingMEnuItemLink();
        //settingsPageObj.setCurrentPasswordIF(Constants.CP_PASSWORD);
        //settingsPageObj.setNewPasswordIF(Constants.CP_PASSWORD);
        //Assert.assertTrue(settingsPageObj.getNotificationDesc().equalsIgnoreCase(""));
        Assert.assertTrue(settingsPageObj.isFirstNameIFReadOnly());
    }

    @Test(description = "Customer portal - settings - change contact number")
    public void TC2303(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        homepageObj.clickOnProfileBtn();
        homepageObj.clickOnsettingMEnuItemLink();
        settingsPageObj.setCurrentPasswordIF(Constants.CP_PASSWORD);
        settingsPageObj.setNewPasswordIF(Constants.CP_PASSWORD);
        settingsPageObj.clearContactNumberIF();
        settingsPageObj.setContactNumberiF("1234567890");
        settingsPageObj.clickOnSaveProfileDetailsBtn();
        Assert.assertTrue(settingsPageObj.getNotificationDesc().equalsIgnoreCase("Details have been updated successfully"));
    }

    @Test(description = "Customer portal - settings - change address")
    public void TC2304(){
        landingPageObj.clickOnLogInBtn();
        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
        signInPFObj.clickOnLogInBtn();
        homepageObj.clickOnProfileBtn();
        homepageObj.clickOnsettingMEnuItemLink();
        settingsPageObj.setCurrentPasswordIF(Constants.CP_PASSWORD);
        settingsPageObj.setNewPasswordIF(Constants.CP_PASSWORD);
        settingsPageObj.clearAddressIF();
        settingsPageObj.setAddressiF("Wellwatte, Colobmo");
        settingsPageObj.clickOnSaveProfileDetailsBtn();
        Assert.assertTrue(settingsPageObj.getNotificationDesc().equalsIgnoreCase("Details have been updated successfully"));
    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }



}
