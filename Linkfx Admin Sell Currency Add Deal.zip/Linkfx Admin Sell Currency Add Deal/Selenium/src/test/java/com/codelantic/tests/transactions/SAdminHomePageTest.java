package com.codelantic.tests.transactions;

import com.codelantic.pages.transactions.LoginPage;
import com.codelantic.pages.transactions.SAdminHomePage;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import com.codelantic.testbase.BaseTest;
import java.util.concurrent.TimeUnit;

public class SAdminHomePageTest extends BaseTest {

    private RemoteWebDriver driver;
    private SAdminHomePage SAdminhomePageObj;
    private CommonOp commonOpObj;

    public SAdminHomePageTest() {

    }

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }
            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
        driver.manage().window().maximize();
    }

    @Test
    public void makeTransfer(){
        LoginPage loginPageObj = new LoginPage(driver, commonOpObj);
        loginPageObj.logInToSAPortal("user@code.com", "Test_1user" );
        SAdminHomePage sAdminHomePageObj  = new SAdminHomePage(driver, commonOpObj);
        Assert.assertTrue(sAdminHomePageObj.isSuperAdminLogoTextVisible().contains("Admin"));
    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            driver.quit();
        }
    }
}
