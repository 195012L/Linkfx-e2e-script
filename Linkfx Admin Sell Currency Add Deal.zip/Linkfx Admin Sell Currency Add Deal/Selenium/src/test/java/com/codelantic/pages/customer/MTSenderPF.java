package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.List;

public class MTSenderPF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MTSenderPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By firstNameIF = By.id("senderFirstName");
    private By lastNameIF = By.id("senderLastName");
    private By telephoneLIF = By.id("tpLand");
    private By telephoneMIF = By.id("tpMobile");
    private By emailIF = By.id("emailAddress");
    private By addressIF = By.id("residentialAddress");
    //private By payementModeIF = By.xpath("//ng-select[@formcontrolname=\"paymentModes\"]/descendant::input");
    private By idTypeIF = By.xpath("//ng-select[@formcontrolname=\"confirmIdentity\"]/descendant::input");
    private By idNumberIF = By.id("identityNumber") ;
    private By cotniueBtn = By.cssSelector(".continue-btn");
    private By cancelBtn = By.xpath("//div[text()=\"Go Back\"]/parent::a");
    private By loader = By.cssSelector(".loader");
    private By closeNotification = By.cssSelector(".ant-notification-notice-close");
    private By notificationDesccription = By.cssSelector(".ant-notification-notice-description");
    private By clearPaymentModeIF = By.xpath("//ng-select[@formcontrolname=\"paymentModes\"]/descendant::span[@title=\"Clear\"]");
    private By dropDownListUI = By.cssSelector(".ng-dropdown-panel-items");

//    public void setPayementModeIF(String pmode){
//        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
//            WebElement webElement = commonOpObj.waitUntilElementClickable(payementModeIF, Constants.EXPLICIT_TIMEOUT);
//            webElement.click();
//            //commonOpObj.waitUntilElementvisibilityOf(dropDownListUI, Constants.EXPLICIT_TIMEOUT_FOR_DROP_DOWNS);
//            webElement.sendKeys(pmode);
//            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
//            webElement.sendKeys(Keys.ENTER);
//            //commonOpObj.waitUntilElementInvisibilityOfElementLocated(dropDownListUI, Constants.EXPLICIT_TIMEOUT_FOR_DROP_DOWNS);
//        }
//    }

    public void clickOnCLearPaymentModeBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(clearPaymentModeIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnContinueBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            commonOpObj.waitUntilElementClickable(cotniueBtn, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void fillSenderDetailsIFsWithValueSet1(String pmode){
        //setPayementModeIF(pmode);
        clickOnContinueBtn();
    }

    public String getFirstName(){
        return driver.findElement(firstNameIF).getAttribute("value");
    }

    public String getLastName(){
        return driver.findElement(lastNameIF).getAttribute("value");
    }

    public String getTelLandNo(){
        return driver.findElement(telephoneLIF).getAttribute("value");
    }

    public String getTelMobileNo(){
        return driver.findElement(telephoneMIF).getAttribute("value");
    }

    public String getEMail(){
        return  driver.findElement(emailIF).getAttribute("value");
    }

    public String getAdrs(){
        return driver.findElement(addressIF).getAttribute("value");
    }

    public String getIDtype(){
        return driver.findElement(idTypeIF).getAttribute("value");
    }

    public String getIDno(){
        return driver.findElement(idNumberIF).getAttribute("value");
    }

    public List<String> getAllNoticeDesc(){
        return commonOpObj.getAllNotificationDesc(loader, notificationDesccription);
    }

}
