package com.codelantic.pages.aml;

import com.codelantic.utilities.CommonOp;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

public class AMLInfoFirstPF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public AMLInfoFirstPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By firstNameInputField = By.id("firstName");
    private By lastNameInputField = By.id("lastName");
    private By dobInputField = By.xpath("//*[@id=\"dateOfBirth\"]/nz-picker/span/input");
    private By placeOfBirthInputField = By.id("placeOfBirth");
    private By emailInputField = By.id("email");
    private By contactNumberInputField = By.id("contactNumber");
    private By addressLineOneInputField = By.id("addressLineOne");
    private By countryInputField = By.xpath("//label[contains(text(), \"Country\")]//parent::nz-form-label//following-sibling::nz-form-control//descendant::input");
    private By postCodeInputField = By.id("postCode");
    private By selectIDtypeInputField = By.xpath("//div[contains(text(), \"Select ID Type\")]//parent::div//descendant::input");
    private By identificationNumberInputField = By.id("identificationNumber");
    private By idetificationExpireDate = By.xpath("//nz-date-picker[@id=\"identificationExpireDate\"]//descendant::input");
    private By continueBtn = By.xpath("//span[contains(text(), \"Continue\")]/parent::span/parent::button");


}
