package com.bankingcore.automationutil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

/**
 * provides file upload/download function through FTP
 * 
 * @author madusanka@codelantic.com
 * @see referred_document_1: <a href
 *      ="https://www.codejava.net/java-se/ftp/connect-and-login-to-a-ftp-server">www.codejava.net</a>
 * @see referred_document_2:
 *      <a href ="https://www.baeldung.com/java-ftp-client">www.baeldung.com</a>
 */
public class FTPConnectionUtil {

	private static final String HOST = "ftp.codelantic-automation.tk";
	private static final String PORT = "21";
	private static final String USER = "automation@codelantic-automation.tk";
	private static final String PASSWORD = "Codelantic@2020";
	private static final String BASE_PATH = "/Automation/";

	private static final Logger logger = Logger.getLogger(FTPConnectionUtil.class.getName());

	private FTPClient ftpClient = null;

	/**
	 * Opens a FTP connection
	 */
	public void openConnection() {
		logger.log(Level.INFO, "FTPConnectionUtil.openConnection() invoked. Host - [{0}], user - [{1}] ",
				new Object[] { HOST, USER });
		ftpClient = new FTPClient();
		try {
			ftpClient.enterLocalPassiveMode();
//	        ftpClient.execPBSZ(0);
			ftpClient.connect(HOST, Integer.parseInt(PORT));
			showServerReply(ftpClient);
			int replyCode = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(replyCode)) {
				logger.log(Level.WARNING, "Operation failed. Server reply code: {0}", replyCode);
			}
			boolean success = ftpClient.login(USER, PASSWORD);
			showServerReply(ftpClient);
			if (!success) {
				logger.log(Level.WARNING, "Could not login to the server");
			} else {
				logger.log(Level.INFO, "LOGGED IN SERVER");
			}
		} catch (Exception e) {
			logger.log(Level.WARNING, "Exception occured", e);
			ftpClient = null;
		}
	}

	/**
	 * @param ftpClient
	 */
	private static void showServerReply(FTPClient ftpClient) {
		String[] replies = ftpClient.getReplyStrings();
		if (replies != null && replies.length > 0) {
			for (String aReply : replies) {
				logger.log(Level.INFO, "SERVER: {0}", aReply);
			}
		}
	}

	/**
	 * Close FTP connection
	 */
	public void closeConnection() {
		logger.log(Level.INFO, "FTPConnectionUtil.closeConnection() invoked. Host - [{0}], user - [{1}] ",
				new Object[] { HOST, USER });
		try {
			if (ftpClient != null) {
				ftpClient.disconnect();
				logger.log(Level.INFO,
						"FTPConnectionUtil.closeConnection() Host - [{0}] connection colsed from user - [{1}] ",
						new Object[] { HOST, USER });
			}
		} catch (IOException e) {
			logger.log(Level.WARNING, "Exception occured", e);
		}
	}

	/**
	 * Upload a file to FTP
	 * 
	 * @param file
	 * @param destination
	 */
	public void uploadFile(File file, String destination) {
		logger.log(Level.INFO, "FTPConnectionUtil.uploadFile() invoked. Host - [{0}], user - [{1}] ",
				new Object[] { HOST, USER });
		FileInputStream inputFile = null;
		try {
			inputFile = new FileInputStream(file);
			ftpClient.setFileType(FTP.ASCII_FILE_TYPE);
			ftpClient.storeFile(BASE_PATH + destination, inputFile);
			logger.log(Level.INFO, "FTPConnectionUtil.uploadFile() File Uploaded. file name : [{0}] ", file.getName());
			Thread.sleep(5000);
			inputFile.close();
		} catch (Exception e) {
			logger.log(Level.WARNING, "Exception occured", e);
		}
	}

}
