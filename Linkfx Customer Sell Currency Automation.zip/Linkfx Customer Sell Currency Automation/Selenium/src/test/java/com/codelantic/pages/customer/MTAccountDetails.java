package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

public class MTAccountDetails {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MTAccountDetails(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By OKBtn = By.xpath("//span[text()=\"OK\"]/parent::button");
    private By loader = By.cssSelector(".loader");
    private By closeNotification = By.cssSelector(".ant-notification-notice-close");
    private By notificationDesccription = By.cssSelector(".ant-notification-notice-description");

    public void clickOncloseNotification(){
        commonOpObj.closeNotifications(loader, closeNotification);
    }

    public String getnotificationDesccription(){
        return commonOpObj.getNotificationDesc(loader, notificationDesccription);
    }

    public void waitTillNotificationDetailsScreenAppeared(){
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            commonOpObj.waitUntilElementvisibilityOf(OKBtn, Constants.EXPLICIT_TIMEOUT);
        }
    }
    public void clickOnOkBTn(){
        driver.findElement(OKBtn).click();
    }

}
