package com.Linkfx.datatables;

public class AddDeal {
   
    private String password;
    private String value;
    private String username;
    private String bagNumbers;
    private String reference;
    private String amount;
    private String handlingfee;
    private String commission;
    private String bagno;
    private String bagnumber;
    private String reason;
    private String dealNo;
    private String companyName;
    private String branchName;
    private String branchCode;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String name;
    private String postalCode;
    private String state;
    private String email;
    private String contactNo;
    // Getters and Setters
    
    
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
    public String getBagNumbers() {
        return bagNumbers;
    }

    public void setBagNumbers(String bagNumbers) {
        this.bagNumbers = bagNumbers;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getHandlingfee() {
        return handlingfee;
    }

    public void setHandlingfee(String handlingfee) {
        this.handlingfee = handlingfee;
    }
    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }
    public String getBagno() {
        return bagno;
    }

    public void setBagno(String bagno) {
        this.bagno = bagno;
    }
    public String getBagnumber() {
        return bagnumber;
    }

    public void setBagnumber(String bagnumber) {
        this.bagnumber = bagnumber;
    }
    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getDealNo() {
        return dealNo;
    }

    public void setDealNo(String dealNo) {
        this.dealNo = dealNo;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public String getBranchName() {
        return branchName;
    }
    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }
    public String getBranchCode() {
        return branchCode;
    }
    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }
    public String getAddressLine1() {
        return addressLine1;
    }
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine2() {
        return addressLine2;
    }
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getContactNo() {
        return contactNo;
    }
    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }
}
