package com.codelantic.pages.customer;

import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SettingsPage extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SettingsPage(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By newPasswordIF = By.xpath("//input[@formcontrolname=\"newPassword\"]");
    private By currentPasswordIF = By.xpath("//input[@formcontrolname=\"currentPassword\"]");
    private By emailIF = By.xpath("//input[@formcontrolname=\"email\"]");
    private By firstNameiF = By.xpath("//input[@formcontrolname=\"firstName\"]");
    private By contactNumberiF = By.xpath("//input[@formcontrolname=\"contactNumber\"]");
    private By addressiF = By.xpath("//input[@formcontrolname=\"address\"]");
    private By saveProfileDetailsBtn = By.xpath("//span[text()=\"Save Profile\"]/parent::button");
    private By loader = By.cssSelector(".loader");
    private By notificationDesccription = By.cssSelector(".ant-notification-notice-description");

    public void setCurrentPasswordIF(String pswd){
        driver.findElement(currentPasswordIF).sendKeys(pswd);
    }

    public void setNewPasswordIF(String pswd){
        driver.findElement(newPasswordIF).sendKeys(pswd);
    }

    public void setContactNumberiF(String number){
        driver.findElement(contactNumberiF).sendKeys(number);
    }

    public void setAddressiF(String adrs){
        driver.findElement(addressiF).sendKeys(adrs);
    }

    public void clickOnSaveProfileDetailsBtn(){
        driver.findElement(saveProfileDetailsBtn).click();
    }

    public String getNotificationDesc(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(notificationDesccription, Constants.EXPLICIT_TIMEOUT);
            return webElement.getText();
        }
        return null;
    }

    public boolean isFirstNameIFReadOnly(){
        return driver.findElement(firstNameiF).isEnabled();
    }

    public void clearContactNumberIF(){
        driver.findElement(contactNumberiF).clear();
    }

    public void clearAddressIF(){
        driver.findElement(addressiF).clear();
    }

}
