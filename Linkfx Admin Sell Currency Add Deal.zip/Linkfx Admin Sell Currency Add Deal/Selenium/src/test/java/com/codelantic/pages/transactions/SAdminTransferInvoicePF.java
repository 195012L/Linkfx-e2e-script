package com.codelantic.pages.transactions;

public class SAdminTransferInvoicePF {
}
