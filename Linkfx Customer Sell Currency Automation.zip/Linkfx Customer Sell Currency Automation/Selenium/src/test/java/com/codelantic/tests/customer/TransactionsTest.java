package com.codelantic.tests.customer;

import com.codelantic.pages.customer.*;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import com.sun.corba.se.impl.orbutil.closure.Constant;
import com.sun.xml.internal.bind.v2.runtime.reflect.opt.Const;
import net.bytebuddy.matcher.CollectionOneToOneMatcher;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class TransactionsTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignInPF signInPFObj;
    private HomePage homePageObj;
    private MTTransferDetailsPF mtTransferDetailsPFObj;
    private MTSenderPF mtSenderPFObj;
    private MTBeneficiaryPF mtBeneficiaryPFObj;
    private MTInvoicePF mtInvoicePFObj;
    private MTAccountDetails mtAccountDetailsObj;
    private MTCardPayment mtCardPaymentObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }

            driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);
            driver.manage().window().maximize();

            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);
            homePageObj = new HomePage(driver, commonOpObj);
            mtTransferDetailsPFObj = new MTTransferDetailsPF(driver, commonOpObj);
            mtSenderPFObj = new MTSenderPF(driver, commonOpObj);
            mtBeneficiaryPFObj = new MTBeneficiaryPF(driver, commonOpObj);
            mtInvoicePFObj = new MTInvoicePF(driver, commonOpObj);
            mtAccountDetailsObj = new MTAccountDetails(driver, commonOpObj);
            mtCardPaymentObj = new MTCardPayment(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
    }

    @Test(invocationCount = 1, description = "New Beneficiary new Bank")
    public void MakeTransferWithValuesSet1_T1(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.setPayementModeIF(Constants.PAYMODE_BANK_DEPOSIT);
        mtTransferDetailsPFObj.clickOnContinueBtn();

        mtVerifySenderDetailsSet1();
        mtSenderPFObj.clickOnContinueBtn();
        //mtSenderPFObj.fillSenderDetailsIFsWithValueSet1(Constants.MOT_BANK_DEPOSIT);

        mtBeneficiaryPFObj.fillBenificiaryNewBeniNewBank(Constants.NEW_BENI_FN,  Constants.NEW_BENI_lN, Constants.NEW_BENI_cN,
                Constants.NEW_BENI_ADRS, Constants.MT_SET1_RECIPIENT_CNTRY, Constants.NEW_BANK_BN, Constants.NEW_BANK_BACC,
                Constants.NEW_BANK_BB, Constants.NEW_BANK_BC, Constants.NEW_BANK_SFT);
        mtBeneficiaryPFObj.setReference(Constants.MT_SET1_REF);
        mtBeneficiaryPFObj.clickOnContinueBtn();

        mtVerifyTransferDetailsWithInvoiceDetailsSet2();
        Assert.assertEquals(mtInvoicePFObj.confirmAndCLoseTheTransaction(), Constants.MT_INVOICE_SUCCESS_NOTIFICATION);

        mtAccountDetailsObj.waitTillNotificationDetailsScreenAppeared();
        Assert.assertTrue(driver.getPageSource().contains(Constants.MT_ACC_DETAILS_PAYMENT_NOTE));
        Assert.assertEquals(mtAccountDetailsObj.getnotificationDesccription(), Constants.MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION);
        mtAccountDetailsObj.clickOncloseNotification();
        mtAccountDetailsObj.clickOnOkBTn();
        homePageObj.logOutfromCP();
    }

    @Test(invocationCount = 1, description = "Existing Beneficiary and Existing Bank")
    public void MakeTransferWithValuesSet1_T2(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.setPayementModeIF(Constants.PAYMODE_BANK_DEPOSIT);
        mtTransferDetailsPFObj.clickOnContinueBtn();

        mtVerifySenderDetailsSet1();
        mtSenderPFObj.clickOnContinueBtn();
        //mtSenderPFObj.fillSenderDetailsIFsWithValueSet1(Constants.MOT_BANK_DEPOSIT);

        mtBeneficiaryPFObj.fillBenificiaryOldBeniOldBank(Constants.MT_SET1_BENI_NAME, Constants.MT_SET1_RECIPIENT_CNTRY);
        mtBeneficiaryPFObj.setReference(Constants.MT_SET1_REF);
        mtBeneficiaryPFObj.clickOnContinueBtn();

        mtVerifyTransferDetailsWithInvoiceDetailsSet1();
        Assert.assertEquals(mtInvoicePFObj.confirmAndCLoseTheTransaction(), Constants.MT_INVOICE_SUCCESS_NOTIFICATION);

        mtAccountDetailsObj.waitTillNotificationDetailsScreenAppeared();
        Assert.assertTrue(driver.getPageSource().contains(Constants.MT_ACC_DETAILS_PAYMENT_NOTE));
        Assert.assertEquals(mtAccountDetailsObj.getnotificationDesccription(), Constants.MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION);
        mtAccountDetailsObj.clickOncloseNotification();
        mtAccountDetailsObj.clickOnOkBTn();
        homePageObj.logOutfromCP();
    }

    @Test(invocationCount = 20, description = "Existing Beneficiary and Existing Bank")
    public void MakeTransferWithValuesSet1_T3(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        homePageObj.fillSendMoneyFormWithValuesSet1_Get_started(Constants.MT_SET1_SENDING_CNTRY, Constants.MT_SET1_RECIEVING_CNTRY,
                Constants.MT_SET1_SENDING_AMOUNT, Constants.MT_SET1_RECIEVING_AMOUNT);

        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
        mtTransferDetailsPFObj.setPayementModeIF(Constants.PAYMODE_DEBIT_CARD);
        mtTransferDetailsPFObj.clickOnContinueBtn();

        mtVerifySenderDetailsSet1();
        mtSenderPFObj.clickOnContinueBtn();
        //mtSenderPFObj.fillSenderDetailsIFsWithValueSet1(Constants.MOT_BANK_DEPOSIT);

        mtBeneficiaryPFObj.fillBenificiaryOldBeniOldBank(Constants.MT_SET1_BENI_NAME, Constants.MT_SET1_RECIPIENT_CNTRY);
        mtBeneficiaryPFObj.setReference(Constants.MT_SET1_REF);
        mtBeneficiaryPFObj.clickOnContinueBtn();

        //mtVerifyTransferDetailsWithInvoiceDetailsSet1();
        //Assert.assertEquals(mtInvoicePFObj.confirmAndCLoseTheTransaction(), Constants.MT_INVOICE_SUCCESS_NOTIFICATION);

        mtInvoicePFObj.confirmAndCLoseTheTransaction();
        mtCardPaymentObj.setDebitCardDetailsForVISAandPay("VISA", "4200000000000000",
                "1223", "123", "Test User");

        //mtAccountDetailsObj.waitTillNotificationDetailsScreenAppeared();
        //Assert.assertTrue(driver.getPageSource().contains(Constants.MT_ACC_DETAILS_PAYMENT_NOTE));
        //Assert.assertEquals(mtAccountDetailsObj.getnotificationDesccription(), Constants.MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION);
        //mtAccountDetailsObj.clickOncloseNotification();
        //mtAccountDetailsObj.clickOnOkBTn();

        homePageObj.logOutfromCP();

        landingPageObj.waitTillLogInBtnDisplaying();
    }


    public void mtVerifySenderDetailsSet1(){
        Assert.assertEquals(mtSenderPFObj.getFirstName(), Constants.MT_SET1_SENDER_FIRST_NAME);
        Assert.assertEquals(mtSenderPFObj.getLastName(), Constants.MT_SET1_SENDER_LAST_NAME);
        Assert.assertEquals(mtSenderPFObj.getTelLandNo(), Constants.MT_SET1_SENDER_TEL_LAND);
        Assert.assertEquals(mtSenderPFObj.getTelMobileNo(), Constants.MT_SET1_SENDER_TEL_MOBILE);
        Assert.assertEquals(mtSenderPFObj.getEMail(), Constants.MT_SET1_SENDER_EMAIL);
        Assert.assertEquals(mtSenderPFObj.getAdrs(), Constants.MT_SET1_SENDER_ADRS);
        //Assert.assertEquals(mtSenderPFObj.getIDtype(), Constants.MT_SET1_SENDER_ID_TYPE); ToDo:validate this value
        Assert.assertEquals(mtSenderPFObj.getIDno(), Constants.MT_SET1_SENDER_ID_NO);

    }


    @Test(invocationCount = 1, description = "")
    public void TransactionsFLowBasicValidationsEmptyValues(){
        landingPageObj.clickOnLogInBtn();

        signInPFObj.loginToCP(Constants.CP_USERNAME, Constants.CP_PASSWORD);

        //send amount -> empty value
        homePageObj.waituntilLoginDisappear();
        homePageObj.setRecipientCountryIF(Constants.MT_SET1_RECIEVING_CNTRY);
        homePageObj.clickOnGetStarted_make_transfer();
        List<String> listOfNotificatiosn = commonOpObj.getAllNotificationDescHC();
        Assert.assertTrue(listOfNotificatiosn.contains(Constants.NOTIFICATION_SEND_AMOUNT_EMPTY_N));

//        mtTransferDetailsPFObj.setModeOFTransfer(Constants.MOT_BANK_DEPOSIT);
//        mtTransferDetailsPFObj.clickOnContinueBtn();
//
//        mtVerifySenderDetailsSet1();
//        mtSenderPFObj.fillSenderDetailsIFsWithValueSet1(Constants.MOT_BANK_DEPOSIT);
//
//        mtBeneficiaryPFObj.fillBenificiaryNewBeniNewBank(Constants.NEW_BENI_FN,  Constants.NEW_BENI_lN, Constants.NEW_BENI_cN,
//                Constants.NEW_BENI_ADRS, Constants.MT_SET1_RECIPIENT_CNTRY, Constants.NEW_BANK_BN, Constants.NEW_BANK_BACC,
//                Constants.NEW_BANK_BB, Constants.NEW_BANK_BC, Constants.NEW_BANK_SFT);
//        mtBeneficiaryPFObj.setReference(Constants.MT_SET1_REF);
//        mtBeneficiaryPFObj.clickOnContinueBtn();
//
//        mtVerifyTransferDetailsWithInvoiceDetailsSet2();
//        Assert.assertEquals(mtInvoicePFObj.confirmAndCLoseTheTransaction(), Constants.MT_INVOICE_SUCCESS_NOTIFICATION);
//
//        mtAccountDetailsObj.waitTillNotificationDetailsScreenAppeared();
//        Assert.assertTrue(driver.getPageSource().contains(Constants.MT_ACC_DETAILS_PAYMENT_NOTE));
//        Assert.assertEquals(mtAccountDetailsObj.getnotificationDesccription(), Constants.MT_ACCOUNT_DETAILS_SUCCESS_NOTIFICATION);
//        mtAccountDetailsObj.clickOncloseNotification();
//        mtAccountDetailsObj.clickOnOkBTn();
//        homePageObj.logOutfromCP();
    }


    public void mtVerifyTransferDetailsWithInvoiceDetailsSet1(){
        Assert.assertEquals(mtInvoicePFObj.getsenderNameIF(), Constants.MT_SET1_SENDER_FULL_NAME);
        Assert.assertEquals(mtInvoicePFObj.gettransferredAmountIF(), Constants.MT_SET1_SENDING_AMOUNT);
        Assert.assertEquals(mtInvoicePFObj.getbeneficiaryNameIF(), Constants.MT_SET1_BENI_NAME);
        Assert.assertEquals(mtInvoicePFObj.getmodeOfServiceIF(), Constants.MT_SET1_SENDER_PAY_MODE);
        Assert.assertEquals(mtInvoicePFObj.getreceivedAmountIF(), Constants.MT_SET1_RECIEVING_AMOUNT);
    }

    public void mtVerifyTransferDetailsWithInvoiceDetailsSet2(){
        Assert.assertEquals(mtInvoicePFObj.getsenderNameIF(), Constants.MT_SET1_SENDER_FULL_NAME);
        Assert.assertEquals(mtInvoicePFObj.gettransferredAmountIF(), Constants.MT_SET1_SENDING_AMOUNT);
        Assert.assertEquals(mtInvoicePFObj.getbeneficiaryNameIF(), Constants.NEW_BENI_FULL_NAME);
        Assert.assertEquals(mtInvoicePFObj.getmodeOfServiceIF(), Constants.MT_SET1_SENDER_PAY_MODE);
        Assert.assertEquals(mtInvoicePFObj.getreceivedAmountIF(), Constants.MT_SET1_RECIEVING_AMOUNT);
    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            //driver.quit();
        }
    }


}
