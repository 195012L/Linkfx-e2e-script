package com.codelantic.pages.customer;

import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class NavMenu extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public NavMenu(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By settingsBtn = By.cssSelector(".settings-btn");
    private By myTransactionsLink = By.xpath("//span[text()=\"My Transactions\"]//parent::li");
    private By beneficiariesLink = By.xpath("//span[text()=\"Beneficiaries\"]//parent::li");
    private By loader = By.cssSelector("loader");
    private By profileBtn = By.cssSelector(".profile-btn");
    private By signOutBtn = By.xpath("//li[text()=\"Sign Out\"]");

    public void clickOnSettingsBtn(){
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement webElement = commonOpObj.waitUntilElementClickable(settingsBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnMyTransLink(){
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement webElement = commonOpObj.waitUntilElementClickable(myTransactionsLink, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnBeniLink(){
        if (commonOpObj.waitUntilElementInvisibilityOfElementLocated(loader, Constants.EXPLICIT_TIMEOUT)) {
            WebElement webElement = commonOpObj.waitUntilElementClickable(beneficiariesLink, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnProfileBtn(){
        commonOpObj.waitUntilElementClickable(profileBtn, Constants.EXPLICIT_TIMEOUT).click();
    }

    public void clickOnsignOutBtn(){
        commonOpObj.waitUntilElementClickable(signOutBtn,Constants.EXPLICIT_TIMEOUT).click();
    }

    public void signOutfromCP(){
        clickOnProfileBtn();
        clickOnsignOutBtn();
    }

}
