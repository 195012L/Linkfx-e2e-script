package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

public class MyTransactions {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MyTransactions(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By Row1Date = By.xpath("//table/tbody/tr[1]/td[1]");
    private By Row1transferRef = By.xpath("//table/tbody/tr[1]/td[2]");
    private By Row1beniName = By.xpath("//table/tbody/tr[1]/td[3]");
    private By Row1TransferdAmount = By.xpath("//table/tbody/tr[1]/td[4]");
    private By Row1RecievedAMount = By.xpath("//table/tbody/tr[1]/td[5]");
    private By Row1Status = By.xpath("//table/tbody/tr[1]/td[6]");
    private By Row1VIewBtn = By.xpath("//table/tbody/tr[1]/td[7]/a");
    private By loader = By.cssSelector(".loader");
    private By profileBtn = By.cssSelector(".profile-btn");

    public String getRow1Date() {
        return driver.findElement(Row1Date).getText();
    }

    public String getRow1transferRef() {
        return driver.findElement(Row1transferRef).getText();
    }

    public String getRow1beniName() {
        return driver.findElement(Row1beniName).getText();
    }

    public String getRow1TransferdAmount() {
        return driver.findElement(Row1TransferdAmount).getText();
    }

    public String getRow1RecievedAMount() {
        return driver.findElement(Row1RecievedAMount).getText();
    }

    public String getRow1Status() {
        return driver.findElement(Row1Status).getText();
    }

    public void clickOnRow1VIewBtn() {
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            commonOpObj.waitUntilElementClickable(Row1VIewBtn, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

}
