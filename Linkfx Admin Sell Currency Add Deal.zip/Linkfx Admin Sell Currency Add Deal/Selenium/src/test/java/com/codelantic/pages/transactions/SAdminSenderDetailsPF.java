package com.codelantic.pages.transactions;

import com.codelantic.utilities.CommonOp;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SAdminSenderDetailsPF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SAdminSenderDetailsPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    //private By


}
