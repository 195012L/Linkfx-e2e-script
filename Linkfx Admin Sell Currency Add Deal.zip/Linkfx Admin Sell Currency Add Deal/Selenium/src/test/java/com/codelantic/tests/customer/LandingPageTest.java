package com.codelantic.tests.customer;

import com.codelantic.pages.customer.LandingPage;
import com.codelantic.pages.customer.SignInPF;
import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import com.codelantic.utilities.SetupDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;

public class LandingPageTest extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;
    private LandingPage landingPageObj;
    private SignInPF signInPFObj;

    @BeforeClass
    public void InitClass() {
        try {
            if (hub.isEmpty()) {
                driver = SetupDriver.getDriver(driver, browser, baseUrl);
            } else {
                driver = SetupDriver.getDriver(driver, hub, browser, baseUrl);
            }

            driver.manage().timeouts().implicitlyWait(implicitWaitTimeout, TimeUnit.MILLISECONDS);
            commonOpObj = new CommonOp(driver);
            landingPageObj = new LandingPage(driver, commonOpObj);
            signInPFObj = new SignInPF(driver, commonOpObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public void InitTest() {
        driver.get(baseUrl);
        driver.manage().window().maximize();
    }

    @Test(description = "customer try to sign in to portal")
    public void TC2001(){
        Assert.assertTrue(landingPageObj.isShowingSignUpBtn());
    }

    @Test(description = "Customer landing page - Features and basic information section")
    public void TC2006(){
        Assert.assertTrue(landingPageObj.isDisplayedFeatures());
    }

    @Test(description = "Customer landing page - Mobile App section")
    public void TC2007(){
        Assert.assertTrue(landingPageObj.isDisplayedMobileAppSection());
    }

    @Test(description = "customer landing page - Users comment section")
    public void TC2008(){
        Assert.assertTrue(landingPageObj.isDisplayedCommentsSection());
    }

    @Test(description = "customer landing page - footer section")
    public void TC2011_TC2012(){
        Assert.assertTrue(landingPageObj.isDisplayedFooterSection());
    }

    @Test(description = "customer landing page - footer section - content - copy right sign")
    public void TC2013(){
        Assert.assertTrue(landingPageObj.isDisplayedCopyright());
    }

    @Test(description = "customer landing page - footer section - content - Terms and conditions link")
    public void TC2014(){
        landingPageObj.clickOnTermsLink();
        Assert.assertTrue(driver.getPageSource().contains("Terms and Conditions"));
    }

    @Test(description = "customer landing page - footer section - content - About us link // Customer landing page - About Us Section")
    public void TC2015_TC2019(){
        Assert.assertTrue(landingPageObj.checkAboutUsLinks());
    }

    @Test(description = "customer landing page - footer section - content - Disclaimer link")
    public void TC2017(){
        landingPageObj.clickOnDisclaimerLink();
        Assert.assertTrue(driver.getPageSource().contains("Information, materials and services contained in our website are subject to change from time to time without notice."));
    }

    @Test(description = "Customer landing page - How it works? Section")
    public void TC2020(){
        landingPageObj.clickOnHowItWorks();
        Assert.assertTrue(driver.getPageSource().contains("How to send money"));
    }

    @Test(description = "Customer landing page - Contacts Section")
    public void TC2021(){
        landingPageObj.clickOncontactSection();
        Assert.assertTrue(driver.getPageSource().contains("Need Help?"));
    }

    @Test(description = "Customer landing page - Learn More Link")
    public void TC2022(){
        landingPageObj.clickOnLearnMoreLink();
        Assert.assertTrue(driver.getPageSource().contains("How to send money"));
    }

//    @Test(description = "customer landing page - sending money form - Recipient Country input field")
//    public void TC2028(){
//        landingPageObj.clickOnLogInBtn();
//        signInPFObj.setUsernameIF(Constants.CP_USERNAME);
//        signInPFObj.setPasswordIF(Constants.CP_PASSWORD);
//        signInPFObj.clickOnLogInBtn();
//        landingPageObj.selectSendingCountry();
//    }

    @AfterMethod
    public void finalizeMethod() {

    }

    @AfterClass
    public void finalizeClass() {
        if (driver.getSessionId() != null) {
            driver.quit();
        }
    }
}
