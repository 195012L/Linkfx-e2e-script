package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.List;

public class MTTransferDetailsPF {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public MTTransferDetailsPF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By sendingCountryIF = By.xpath("//ng-select[@formcontrolname=\"sendingCountry\"]/descendant::input");
    private By recipientCounrtyIF = By.xpath("//ng-select[@formcontrolname=\"recipientCountry\"]/descendant::input");
    private By sendAmountIF = By.id("sendAmount");
    private By recievedAmount = By.id("amountReceived");
    private By modeOFTransfer = By.xpath("//ng-select[@formcontrolname=\"transactionMode\"]/descendant::input");
    private By transferFee = By.id("transferFee");
    private By TotalPayableAMount = By.id("totalAmountPayable");
    private By continueBtn = By.cssSelector(".continue-btn");
    private By cancelBtn = By.cssSelector(".cancel-cross-btn-link");
    private By loader = By.cssSelector(".loader");
    private By clearRecipientCountryBtn = By.xpath("//ng-select[@formcontrolname=\"recipientCountry\"]/descendant::span[@title=\"Clear all\"]");
    private By closeNotification = By.cssSelector(".ant-notification-notice-close");
    private By notificationDesccription = By.cssSelector(".ant-notification-notice-description");
    private By payementModeIF = By.xpath("//ng-select[@formcontrolname=\"paymentModes\"]/descendant::input");

    public void setSendingCountryIF(String country){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement webElement = driver.findElement(sendingCountryIF);
            WebElement webElement = commonOpObj.waitUntilElementClickable(sendingCountryIF, Constants.EXPLICIT_TIMEOUT);
            //webElement.click();
            webElement.sendKeys(country);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setRecipientCounrtyIF(String country){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement webElement = driver.findElement(recipientCounrtyIF);
            WebElement webElement = commonOpObj.waitUntilElementClickable(recipientCounrtyIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            webElement.sendKeys(country);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setRecipientCounrtyIFtONull(String country){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement webElement = driver.findElement(recipientCounrtyIF);
            WebElement webElement = commonOpObj.waitUntilElementClickable(recipientCounrtyIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(Constants.MT_SET1_RECIEVING_CNTRY);
            webElement.sendKeys(Keys.BACK_SPACE);
            //webElement.click();
        }
    }

    public void setSendAmountIF(String amount){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement webElement = driver.findElement(sendAmountIF);
            WebElement webElement = commonOpObj.waitUntilElementClickable(sendAmountIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(amount);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setModeOFTransfer(String mot){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
           //WebElement webElement = driver.findElement(modeOFTransfer);
            WebElement webElement = commonOpObj.waitUntilElementClickable(modeOFTransfer, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(mot);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void setPayementModeIF(String pmode){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(payementModeIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            //commonOpObj.waitUntilElementvisibilityOf(dropDownListUI, Constants.EXPLICIT_TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(pmode);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
            //commonOpObj.waitUntilElementInvisibilityOfElementLocated(dropDownListUI, Constants.EXPLICIT_TIMEOUT_FOR_DROP_DOWNS);
        }
    }

    public void clickOnContinueBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            commonOpObj.waitUntilElementClickable(continueBtn, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void clickOnCLearRecipientCOuntryBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement webElement = driver.findElement(modeOFTransfer);
            WebElement webElement = commonOpObj.waitUntilElementClickable(clearRecipientCountryBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void fillTransferDetailsIFsWithValueSet1(
            String sendingcountry, String recipientcountry, String s_amount, String r_amount, String mot, String pmode){

        setSendingCountryIF(sendingcountry);
        setRecipientCounrtyIF(recipientcountry);
        setSendAmountIF(s_amount);
        setModeOFTransfer(mot);
        setPayementModeIF(pmode);
        clickOnContinueBtn();
    }

    public List<String> getAllNoticeDesc(){
        return commonOpObj.getAllNotificationDesc(loader, notificationDesccription);
    }

    public void setSendAmountIFtoEmpty(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            //WebElement webElement = driver.findElement(sendAmountIF);
            WebElement webElement = commonOpObj.waitUntilElementClickable(sendAmountIF, Constants.EXPLICIT_TIMEOUT);
            webElement.clear();
            //webElement.sendKeys("0");
            webElement.sendKeys(Keys.ENTER);
        }
    }
}
