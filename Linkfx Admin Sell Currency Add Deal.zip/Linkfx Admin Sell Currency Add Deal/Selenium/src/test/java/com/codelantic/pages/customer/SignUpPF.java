package com.codelantic.pages.customer;

import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.List;

public class SignUpPF extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SignUpPF(RemoteWebDriver driver, CommonOp commonOpOj) {
        this.driver = driver;
        this.commonOpObj = commonOpOj;
    }

    private By firstNameIF = By.id("firstName");
    private By lastNameIF = By.id("lastName");
    private By contactNumberIF = By.id("contactNumber");
    private By userNameIF = By.id("userName");
    private By passwordIF = By.id("password");
    private By confirmPasswordIF = By.id("confirmPassword");
    private By addressLineOneIF = By.id("addressLineOne");
    private By postCodeIF = By.id("postCode");
    private By countryIF = By.xpath("//ng-select[@bindlabel=\"countryName\"]/descendant::input");
    private By continueBtn = By.cssSelector(".continue-btn");
    private By cancelBtn = By.cssSelector(".cancel-btn");
    private By loader = By.cssSelector(".loader");
    private By closeNotification = By.cssSelector(".ant-notification-notice-close");
    private By notificationDesccription = By.cssSelector(".ant-notification-notice-description");

    public void setFirstNameIF(String fname){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(firstNameIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(fname);
        }
    }

    public void setLastNameIF(String lname){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(lastNameIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(lname);
        }
    }

    public void setContactNumberIF(String cnumber){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(contactNumberIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(cnumber);
        }
    }

    public void setUserNameIF(String un){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(userNameIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(un);
        }
    }

    public void setPasswordIF(String pswd){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(passwordIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(pswd);
        }
    }

    public void setConfirmPasswordIF(String rpswd){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(confirmPasswordIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(rpswd);
        }
    }

    public void setAddressLineOneIF(String adrs){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(addressLineOneIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(adrs);
        }
    }

    public void setPostCodeIF(String pstcd){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(postCodeIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(pstcd);
        }
    }

    public void setCountryIF(String country){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(countryIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            webElement.sendKeys(country);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void clickOnCountryIF(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(countryIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            System.out.println(webElement.getText());
        }
    }

    public void clickOnContinueBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(continueBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnCancelBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cancelBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void closeNotifications(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            WebElement webElement = commonOpObj.waitUntilElementClickable(closeNotification, Constants.EXPLICIT_TIMEOUT);
            List<WebElement> errors = commonOpObj.waitUntilElementsvisibilityOf(closeNotification, Constants.EXPLICIT_TIMEOUT);
            for(WebElement ele : errors){
                ele.click();
            }
        }
    }

    public String getNotificationDesc(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(notificationDesccription, Constants.EXPLICIT_TIMEOUT);
           return webElement.getText();
        }
        return null;
    }

    public void fillSignUpPFwithValues(String fn, String ln, String contactNo, String un,
                                       String pswd, String cnPswd, String adrs, String post, String cntry){

        setFirstNameIF(fn);
        setLastNameIF(ln);
        setContactNumberIF(contactNo);
        setUserNameIF(un);
        setPasswordIF(pswd);
        setConfirmPasswordIF(cnPswd);
        setAddressLineOneIF(adrs);
        setPostCodeIF(post);
        setCountryIF(cntry);
    }

}
