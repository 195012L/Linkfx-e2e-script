package com.Linkfx.automation.seleniumpages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;

import com.Linkfx.automation.BasePage;
import com.Linkfx.automation.ConfigFileReader;
import com.Linkfx.datatables.AddUser;
import com.Linkfx.datatables.AddDeal;
import com.Linkfx.utils.CommonOp;
import com.Linkfx.utils.Constants;
import com.paulhammant.ngwebdriver.NgWebDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;


import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AdminAddDeal extends BasePage {
	CommonOp commonOpObj = null;
	ConfigFileReader configFileReader = null;
	By loginIF = By.xpath("//body/app-root[1]/app-login[1]/div[1]");
	
	
	public void launchChromeBrowser() {
		
		driver.manage().window().maximize();
		configFileReader = new ConfigFileReader();

		ChromeOptions options = new ChromeOptions();
	
		options.addArguments("disable-infobars");
		JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
		NgWebDriver ngDriver = new NgWebDriver(jsDriver);
		
		driver.get(configFileReader.getApplicationUrl());
		ngDriver.waitForAngularRequestsToFinish();
		
		
	}

	
	public void loginAgain(List<AddUser> addUser) {
		
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		WebElement login = driver.findElement(loginIF);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		login.click();
		
		for (AddUser addUser1 : addUser){
			
			WebElement username = driver.findElement(By.xpath("//input[@id='username']"));
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			username.sendKeys(addUser1.getUsername());
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
            
			
			WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			password.sendKeys(addUser1.getPassword());
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
			
			driver.findElement(By.xpath("//body/app-root[1]/app-login[1]/div[1]/div[1]/form[1]/button[1]")).click();
			commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
		}
	}
	
	public void BackofficeTabs() 
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/div[1]/img[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void Dealtab() 
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
	}
	
	public void AddDealbutton()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//li[contains(text(),'Add Deal')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
	}
	public void DealHeading()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[1]/h1[1]"));
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.navigate().refresh();
	}
	public void CheckTrans()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[1]/h1[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
	}
	public void ClickOk()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		 driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-deal-denomination-modal[1]/div[3]/div[1]/button[1]")).click();
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void SelectCompany()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 

		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[1]/div[1]/div[1]/div[1]/div[1]/nz-select[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
		driver.findElement(By.xpath("//li[contains(text(),'Goldman Bullion Ltd')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void SelectCompany1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 

		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-currency-acdeal/form[1]/div/div[1]/div[1]/div[1]/nz-select/div/div")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
		driver.findElement(By.xpath("//li[contains(text(),'Goldman Bullion Ltd')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void SelectBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 

		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[1]/div[1]/div[1]/div[1]/div[2]/nz-select[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
		driver.findElement(By.xpath("//li[contains(text(),'London')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void SelectBranch1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 

		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[1]/div[2]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
		driver.findElement(By.xpath("//li[contains(text(),'London')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void SelectTransactionType()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 

		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-deal/form[1]/div/div[1]/div[2]/div[1]/nz-select/div")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
		driver.findElement(By.xpath("//li[contains(text(),'Sell Currency')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void SelectTransactionType1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 

		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[2]/div[1]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
		driver.findElement(By.xpath("//li[contains(text(),'Sell Currency')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void SelectCurrency()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[1]/div[1]/div[1]/div[2]/div[2]/nz-select[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
		driver.findElement(By.xpath("//li[contains(text(),'PHP - Pesso')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void SelectCurrency1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[2]/div[2]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
		driver.findElement(By.xpath("//li[contains(text(),'USD - United States Dollar')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void SelectDate()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[1]/div[1]/div[1]/div[4]/div[1]/div[1]/nz-date-picker[1]/nz-picker[1]/span[1]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
		driver.findElement(By.xpath("//tbody/tr[2]/td[6]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void EnterDeno(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			
			WebElement amount = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-deal-denomination-modal/form/div[1]/div/div[2]/input"));
		        amount.sendKeys(addDeal1.getValue());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);       
				       
		}	
	}
	public void EnterFeeCommission(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);        
		        WebElement handlingfee = driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-deal/form[1]/div/div[1]/div[6]/div[2]/div/input"));
		        
		        handlingfee.sendKeys(addDeal1 .getHandlingfee());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		        WebElement commission = driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-deal/form[1]/div/div[1]/div[6]/div[3]/div/input"));
		       
		        commission.sendKeys(addDeal1 .getCommission());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		}
	}
	public void EnterFeeCommission1(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);        
		        WebElement handlingfee = driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[6]/div[2]/div[1]/input[1]"));
		        
		        handlingfee.sendKeys(addDeal1 .getHandlingfee());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		        WebElement commission = driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[6]/div[3]/div[1]/input[1]"));
		       
		        commission.sendKeys(addDeal1 .getCommission());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		}
	}
	public void SelectDeno()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-deal/form[1]/div/div[1]/div[5]/div/div/span")).click();

		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-deal-denomination-modal[1]/form[1]/div[1]/div[1]/div[2]/input[1]")).click();
        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
	}
	public void SelectDeno1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-currency-acdeal/form[1]/div/div[1]/div[4]/div/div/span")).click();
		
	}
	public void ValidateDenoBox()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-deal-denomination-modal[1]/form[1]/div[1]/div[1]/div[2]/input[1]")).click();
        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		
	}
	public void EnterAmount(List<AddDeal> addDeal) 
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			
		        WebElement amount = driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[1]/div[1]/div[1]/div[3]/div[1]/div[1]/input[1]"));
		        amount.sendKeys(addDeal1 .getAmount());       
		}
	}	
	public void EnterAmount1(List<AddDeal> addDeal) 
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			
		        WebElement amount = driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[3]/div[1]/div[1]/input[1]"));
		        amount.sendKeys(addDeal1 .getAmount());       
		}
	}	
	public void CompleteTrans()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[2]/div[5]/div[1]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void CheckTransField()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//h2[contains(text(),'Transaction')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void CheckTransField1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/div[4]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void CheckSettlement()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-deal[1]/form[2]/div[2]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void CheckSettlement1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[2]/div[2]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void AddCurrency()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-deal/div/div[2]/app-add-deal/form[1]/div/div[1]/div[8]/div/button[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void AddCurrency1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-deal[1]/div[1]/div[2]/app-add-currency-acdeal[1]/form[1]/div[1]/div[1]/div[8]/div[1]/button[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void CompleteTransaction()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//button[contains(@class, 'update-btn') and contains(@class, 'ant-btn') and contains(@class, 'ant-btn-primary')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}

	public void Popup()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//div[contains(text(),'Deal Summary')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void OrderTab()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void OrderHeading()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[1]/div[1]/div[1]/h1[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	
	public void AdminRedirect(List<AddDeal> addDeal) 
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
			driver.findElement(By.xpath("//h3[contains(text(),'Back Office')]")).click();
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
			
			
		}
	}
	public void RedirectDeal()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/button[1]/span[1]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void ClickACDeal()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.findElement(By.xpath("//li[contains(text(),'Currency A/C Deal')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void ValiHeadingAC()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		driver.findElement(By.xpath("//h2[contains(text(),'Currency A/C Deal')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void RedirOrder()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
	}
	public void validateheading()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[1]/div[1]/div[1]/h1[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void validatetotalBuy() 
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void validateView() 
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		driver.findElement(By.xpath("//tbody/tr[1]/td[15]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		
	}
	public void CheckAllBuy()
	{
		driver.findElement(By.xpath("//div[contains(text(),'View Order Details')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
	}
	public void ClickOrder()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateOrder()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[1]/div[1]/div[1]/h1[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickDenomination()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[10]/span[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateDenomination()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-denomination-modal[1]/div[1]/nz-tabset[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void Checkpopup()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//div[contains(text(),'Denomination')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);	
	}
	public void Closepopup()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/button[1]/span[1]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);	
	}
	public void ClickPaymentReceived()
	{	
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-orders/div/div[2]/div/div[4]/div/nz-table/nz-spin/div/div/div/div/div/table/tbody/tr[1]/td[11]/nz-switch/button")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
		
	}
	public void ClickPaymentReceivedMessage()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[12]/button[1]"));
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickTransactionType()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[5]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_LESS);	
	}
	public void SelecttheTransactionType()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM); 
		driver.findElement(By.xpath("/html/body/div/div[3]/div/div/div/ul/li[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelecttheTransactionTypeBuy()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM); 
		driver.findElement(By.xpath("/html/body/div/div[3]/div/div/div/ul/li[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickPaymentReceived1()
	{	
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-orders/div/div[2]/div/div[4]/div/nz-table/nz-spin/div/div/div/div/div/table/tbody/tr[1]/td[11]/nz-switch/button")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
		
	}
	public void ClickPaymentReceivedMessage1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-orders/div/div[2]/div/div[4]/div/nz-table/nz-spin/div/div/div/div/div/table/tbody/tr[1]/td[12]/button"));
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	
	public void ClickPending()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[12]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidatePopup()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM); 
		driver.findElement(By.xpath("//div[contains(text(),'Transaction Denomination')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);	
	}
	public void SettlementDeno()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM); 
		driver.findElement(By.xpath("//div[contains(text(),'Settlement Denomination')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);	
	}
	public void EnterBagNo(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);        
		        WebElement bagno = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-settlement-denomination/div/nz-tabset/div[2]/div[2]/div/form/div[2]/div/input"));
		        bagno.sendKeys(addDeal1.getBagno());
		        commonOpObj.Sleep(Constants.WAITING_TIME_LESS);
		        
		}
	}
	public void UpdateTrans()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-settlement-denomination/div/nz-tabset/div[2]/div[2]/div/button")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterBagNo1(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement bagnumber = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-settlement-denomination/div/nz-tabset/div[2]/div[2]/div/form/div[2]/div/input"));
		        bagnumber.sendKeys(addDeal1.getBagnumber());
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        
		}
	}
	public void UpdateTrans1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-settlement-denomination[1]/div[1]/nz-tabset[1]/div[2]/div[2]/div[1]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	
	public void ClickPending1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-orders/div/div[2]/div/div[4]/div/nz-table/nz-spin/div/div/div/div/div/table/tbody/tr[1]/td[12]/button")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickDownload()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/div[2]/div[1]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateDownload()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.location.href = 'chrome://downloads/'");
		
	}
	public void ClickSummaryDownload()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/div[2]/div[1]/button[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickInvoiceDownload()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[17]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickDeactivate()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[18]/td[16]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickValidateDeactivate()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Are you sure delete this Transaction?')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterReason(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement bagnumber = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-delete-deal-modal/div[1]/div/div/textarea"));
		        bagnumber.sendKeys(addDeal1.getReason());
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        
		}
	}
	public void ClickYesButton()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-delete-deal-modal[1]/div[2]/div[1]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);	
	}
	public void ClickCompanyDropdown()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Company')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectCompany2()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Monex')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateCompany2()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[3]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickBranchDropdown()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Branch')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectBranch2()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Paddington')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[4]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickDealDropdown()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Deal Type')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectDeal()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'DIRECT DEAL')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateDeal()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[8]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickCurrency()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Currency')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectCurrency2()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'AUD - Australia')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateCurrency()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[10]/span[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_HIGH);  
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/button[1]/span[1]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickTransactiontype()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Status')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectTransatype()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Buy Currency')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		
	}
	public void ValidateTranstype()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-orders/div/div[2]/div/div[4]/div/nz-table/nz-spin/div/div/div/div/div/table/tbody/tr[1]/td[12]/button")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-settlement-denomination/div/nz-tabset/div[2]/div[1]/nz-tabset/div[1]/div/div/div/div/div[1]/div/div")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/button[1]/span[1]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterDealNo(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement bagnumber = driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[6]/input[1]"));
		        bagnumber.sendKeys(addDeal1.getDealNo());
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        
		}
	}
	public void ValidateDealNo()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//td[contains(text(),'GBPNOSLF21056')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickTransactionDate()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[1]/nz-range-picker[1]/nz-picker[1]/span[1]/span[1]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectDates()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[1]/date-range-popup[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/inner-popup[1]/div[1]/date-table[1]/table[1]/tbody[1]/tr[1]/td[5]/div[1]")).click();
		driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[1]/date-range-popup[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/inner-popup[1]/div[1]/date-table[1]/table[1]/tbody[1]/tr[4]/td[3]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateSelectedDates()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//td[contains(text(),'Jun 18, 2023')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ReceivePay()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-orders[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[2]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectPay()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Payement Received')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidatePay()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[11]/nz-switch[1]/button[1]"));
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickStock()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[4]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateStockHeading()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-stock[1]/div[1]/div[1]/div[1]/div[1]/h1[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickTill()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-stock[1]/div[1]/div[3]/div[1]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	
	public void SelectTill() 
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Till 01')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);	
	}
	public void ValidateTill()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body[1]/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-stock[1]/div[1]/div[5]/div[1]/div[3]/div[1]/nz-table[1]/nz-spin[1]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/thead[1]/tr[1]/th[3]/span[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectCurrency3()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Currency')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectUSD()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'USD - United States Dollar')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateUSD()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectStatus()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Select Status')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectStatus1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Out of stock')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateStatus()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//tbody/tr[1]/td[4]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickDate()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-stock[1]/div[1]/div[5]/div[1]/div[2]/div[2]/div[1]/nz-date-picker[1]/nz-picker[1]/span[1]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectDate1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'20')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateDate()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.location.href = 'chrome://downloads/'");
	}
	public void ClickDownloads()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-stock[1]/div[1]/div[5]/div[1]/div[2]/div[2]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickExchange()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-sider[1]/div[1]/ul[1]/li[5]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectExchange()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Exchange Rates')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateHeading()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-exchang-rate[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/h1[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void Clickplusicon()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-exchang-rate[1]/form[1]/div[1]/div[1]/div[2]/div[2]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	
	public void EnterCompanyName(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement companyName = driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-company-modal[1]/div[1]/form[1]/div[1]/div[1]/input[1]"));
		        companyName.sendKeys(addDeal1.getCompanyName());
		        commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);
		        
		}
	}
	public void ClickAddCompany()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-company-modal[1]/div[1]/form[1]/div[2]/div[1]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateCompany()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-exchang-rate[1]/form[1]/div[1]/div[1]/div[2]/div[1]/nz-select[1]/div[1]/div[1]")).click();
		driver.findElement(By.xpath("//li[contains(text(),'Walton')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickAddBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-exchang-rate[1]/form[1]/div[1]/div[1]/div[3]/div[2]/i[1]/*[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);	
	}
	public void ClickSelectBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[1]/div[1]/nz-select[1]/div[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectCompany3()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Monex')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickBranchName()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[1]/div[2]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterBranchName(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement branchName = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[1]/div[2]/input"));
		        branchName.sendKeys(addDeal1.getBranchName());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickBranchCode()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[1]/div[3]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterBranchCode(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement branchCode = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[1]/div[3]/input"));
		        branchCode.sendKeys(addDeal1.getBranchCode());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickAddress1()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[2]/div[1]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterAddress1(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement addressLine1 = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[2]/div[1]/input"));
		        addressLine1.sendKeys(addDeal1.getAddressLine1());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickAddress2()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[2]/div[2]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterAddress2(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement addressLine2 = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[2]/div[2]/input"));
		        addressLine2.sendKeys(addDeal1.getAddressLine2());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickCity()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[2]/div[3]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterCity(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement city = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[2]/div[3]/input"));
		        city.sendKeys(addDeal1.getCity());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickState()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[3]/div[1]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterState(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement state = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[3]/div[1]/input"));
		        state.sendKeys(addDeal1.getState());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickName()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[4]/div[1]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterName(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement name = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[4]/div[1]/input"));
		        name.sendKeys(addDeal1.getName());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickPostal()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[3]/div[2]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterPostal(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement postalCode = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[3]/div[2]/input"));
		        postalCode.sendKeys(addDeal1.getPostalCode());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickEmail()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[4]/div[2]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterEmail(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement email = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[4]/div[2]/input"));
		        email.sendKeys(addDeal1.getEmail());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickContactNo()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[4]/div[3]/input[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void EnterContactNo(List<AddDeal> addDeal)
	{
		for (AddDeal addDeal1 : addDeal)
		{
			commonOpObj = new CommonOp(driver);
			commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);        
		        WebElement contactNo = driver.findElement(By.xpath("/html/body/div/div[2]/div/nz-modal/div/div[2]/div/div/div[2]/app-add-new-branch-details-modal/div/form/div[4]/div[3]/input"));
		        contactNo.sendKeys(addDeal1.getContactNo());
		        commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);
		        
		}
	}
	public void ClickBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-add-new-branch-details-modal[1]/div[1]/form[1]/div[8]/div[1]/button[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickingSelectCompany()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-exchang-rate[1]/form[1]/div[1]/div[1]/div[2]/div[1]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectMonex()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Monex')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickingSelectBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/app-root[1]/app-dashboard[1]/nz-layout[1]/nz-layout[1]/nz-content[1]/div[1]/app-exchang-rate[1]/form[1]/div[1]/div[1]/div[3]/div[1]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectQuinton()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Quinton')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickBranchCopy()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("/html/body/app-root/app-dashboard/nz-layout/nz-layout/nz-content/div/app-exchang-rate/form/div/div[1]/div[4]/div/div/span")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ValidateTarget()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//div[contains(text(),'Target Branch Deatils')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickingonSelectCompany()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-copy-branch-modal[1]/form[1]/div[1]/div[1]/div[1]/div[1]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM);	
	}
	public void SelectingMoneyCorp()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_MEDIUM); 
		driver.findElement(By.xpath("//li[contains(text(),'Money corp')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickingonSelectBranch()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-copy-branch-modal[1]/form[1]/div[1]/div[1]/div[1]/div[2]/nz-select[1]/div[1]/div[1]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void SelectonVault()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//li[contains(text(),'Vault')]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	public void ClickingSave()
	{
		commonOpObj = new CommonOp(driver);
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH); 
		driver.findElement(By.xpath("//body/div[1]/div[2]/div[1]/nz-modal[1]/div[1]/div[2]/div[1]/div[1]/div[2]/app-copy-branch-modal[1]/form[1]/div[1]/div[1]/div[1]/div[3]/div[1]/button[2]")).click();
		commonOpObj.Sleep(Constants.WAITING_TIME_OVER_DOUBLE_HIGH);	
	}
	
}   


