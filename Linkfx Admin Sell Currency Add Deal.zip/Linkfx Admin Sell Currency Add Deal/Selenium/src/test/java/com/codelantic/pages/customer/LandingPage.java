package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.List;

public class LandingPage {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    private By signUpBtn = By.xpath("//span[text()='Sign Up']/parent::button");
    private By loginBtn = By.xpath("//span[text()=\"Login\"]/parent::button");
    private By lowcostFeaturesSection = By.xpath("//h3[text()=\"Low Cost\"]");
    private By fastFeaturesSection = By.xpath("//h3[text()=\"Fast\"]");
    private By mobileAppSection = By.xpath("//h1[contains(text(), \"SpotOn Money works\")]");
    private By commentsSection = By.xpath("//h2[contains(text(), \"Join in with others who Love SpotOn Money\")]");
    private By termsFooterSection = By.xpath("//a[contains(text(), \"Terms & Conditions\")]");
    private By disclaimerFooterSection = By.xpath("//a[contains(text(), \"Disclaimer\")]");
    private By aboutUsSection = By.xpath("//a[contains(text(), \"About Us\")]");
    private By copyrightFooterSection = By.xpath("//p[contains(text(), \"2019 Monex International Limited. All rights reserved\")]");
    private By howItWorksSectionLink = By.xpath("//a[contains(text(), \"How it works?\")]");
    private By contactSectionLink = By.xpath("//a[contains(text(), \"Contact\")]");
    private By learnMoreSectionLink = By.xpath("//span[contains(text(), \"Learn More\")]/parent::button");
    private By sendingCountryIF = By.xpath("//label[contains(text(), \"Sending from\")]/ancestor::nz-form-item/descendant::div[contains(text(), \"Select Country\")]");
    private By recipientCountryIF = By.xpath("//label[contains(text(), \"Recipient Country\")]/ancestor::nz-form-item/descendant::div[contains(text(), \"Select Country\")]");


    public LandingPage(RemoteWebDriver remoteWebDriver, CommonOp commonOpObj) {
        this.driver = remoteWebDriver;
        this.commonOpObj = commonOpObj;
    }

    public boolean isShowingSignUpBtn(){
        return driver.findElement(signUpBtn).isDisplayed();
    }

    public boolean isShowingLogInBtn(){
        return driver.findElement(loginBtn).isDisplayed();
    }

    public void waitTillLogInBtnDisplaying(){
        commonOpObj.waitUntilElementvisibilityOf(loginBtn, Constants.EXPLICIT_TIMEOUT);
    }

    public void clickOnLogInBtn(){
        commonOpObj.waitUntilElementClickable(loginBtn, Constants.EXPLICIT_TIMEOUT).click();
    }

    public boolean isDisplayedFeatures(){
        return driver.findElement(lowcostFeaturesSection).isDisplayed()
                && driver.findElement(fastFeaturesSection).isDisplayed();
    }

    public boolean isDisplayedMobileAppSection(){
        return driver.findElement(mobileAppSection).isDisplayed();
    }

    public boolean isDisplayedCommentsSection(){
        return driver.findElement(commentsSection).isDisplayed();
    }

    public boolean isDisplayedFooterSection(){
        return driver.findElement(termsFooterSection).isDisplayed()
                && driver.findElement(disclaimerFooterSection).isDisplayed()
                && driver.findElement(aboutUsSection).isDisplayed();
    }

    public boolean isDisplayedCopyright(){
        return driver.findElement(copyrightFooterSection).isDisplayed();
    }

    public void clickOnTermsLink(){
        driver.findElement(termsFooterSection).click();
    }

    public boolean checkAboutUsLinks(){
        List<WebElement> aboutUsLinks = driver.findElements(aboutUsSection);
        int numOfLinks = aboutUsLinks.size();
        for(int i=0; i<numOfLinks; i++){
            WebElement link = driver.findElements(aboutUsSection).get(i);
            link.click();
            if(!driver.getPageSource().contains("SpotOn Money is a trading arm of Monex International Limited")){
                return false;
            }
            driver.navigate().back();
        }
        return true;
    }

    public void clickOnDisclaimerLink(){
        driver.findElement(disclaimerFooterSection).click();
    }

    public void clickOnHowItWorks(){
        driver.findElement(howItWorksSectionLink).click();
    }

    public void clickOncontactSection(){
        driver.findElement(contactSectionLink).click();
    }

    public void clickOnLearnMoreLink(){
        driver.findElement(learnMoreSectionLink).click();
    }

    public void clickOnSignUpBtn(){
        driver.findElement(signUpBtn).click();
    }

    public void selectSendingCountry(){
        driver.findElement(sendingCountryIF).click();
    }
}
