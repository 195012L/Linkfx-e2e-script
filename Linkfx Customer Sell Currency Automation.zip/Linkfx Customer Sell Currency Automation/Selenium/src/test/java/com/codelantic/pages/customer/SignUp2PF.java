package com.codelantic.pages.customer;

import com.codelantic.testbase.BaseTest;
import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.LinkedList;
import java.util.List;

public class SignUp2PF extends BaseTest {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public SignUp2PF(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private String idImgFrontXpath = "//button[@id=\"frontBtn\"]/preceding-sibling::input";
    private String idImgBackXpath = "//button[@id=\"backBtn\"]/preceding-sibling::input";
    private String idImgSecXpath = "//button[@id=\"secondaryBtn\"]/preceding-sibling::input";

    private By dateOfBirthIF = By.cssSelector("#dateOfBirth > nz-picker > span > input");
    private By placeOfBirthIF = By.id("placeOfBirth");
    private By iDtypeIF = By.xpath("//div[text()=\"Select ID Type\"]/following-sibling::div/child::input");
    private By identificationNumberIF = By.id("identificationNumber");
    private By idExpiryDateIF = By.cssSelector("#identificationExpireDate > nz-picker > span > input");
    private By idFrontIMG = By.xpath(idImgFrontXpath);
    private By idBackIMG = By.xpath(idImgBackXpath);
    private By idSecondaryIF = By.xpath("//div[contains(text(),\"Select Secondary ID Type\")]/following::input");
    private By idSecondaryIMG = By.xpath(idImgSecXpath);
    private By continueBtn = By.cssSelector(".continue-btn");
    private By cancelBtn = By.cssSelector("cancel-btn");
    private By loader = By.cssSelector(".loader");
    private By selectOptionsComboBox = By.cssSelector(".ng-option-label");

    public void setDateOfBirthIF(String dob){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(dateOfBirthIF, Constants.EXPLICIT_TIMEOUT);

            webElement.click();
            driver.findElement(By.linkText("2020")).click();
            driver.findElement(By.linkText("2019")).click();
            driver.findElement(By.linkText("2009")).click();
            driver.findElement(By.linkText("1999")).click();
            driver.findElement(By.linkText("1991")).click();
            driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[1]/following::div[3]")).click();

//            ((JavascriptExecutor)driver).executeScript (
//                    "document.querySelector('#dateOfBirth > nz-picker > span > input').removeAttribute('readonly');");
//            webElement.sendKeys(dob);

//            ((JavascriptExecutor)driver).executeScript (
//                    "document.querySelector('#dateOfBirth > nz-picker > span > input').value = arguments[0];", dob);
        }
    }

    public void setPlaceOfBirthIF(String place){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(placeOfBirthIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(place);
        }
    }

    public void setiDtypeIF(String idType){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(iDtypeIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            webElement.sendKeys(idType);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void clickOnIDtype(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(iDtypeIF, Constants.EXPLICIT_TIMEOUT);
                webElement.click();
            }
    }

    public List<String> getIDtypes(){
        List<String> IDtypes = new LinkedList<>();
        List<WebElement> webelements = driver.findElements(selectOptionsComboBox);
            for(WebElement ele : webelements){
                IDtypes.add(ele.getText());
            }
        return IDtypes;
    }

    public void setIdentificationNumberIF(String idNo){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(identificationNumberIF, Constants.EXPLICIT_TIMEOUT);
            webElement.sendKeys(idNo);
        }
    }

    public void setIdExpiryDateIF(String idExpire){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(idExpiryDateIF, Constants.EXPLICIT_TIMEOUT);

            webElement.click();
            driver.findElement(By.linkText("2020")).click();
            driver.findElement(By.linkText("2024")).click();
            driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[1]/following::div[2]")).click();

//            ((JavascriptExecutor)driver).executeScript (
//                    "document.querySelector('#identificationExpireDate > nz-picker > span > input').removeAttribute('readonly');");
//            webElement.sendKeys(idExpire);

//            ((JavascriptExecutor)driver).executeScript (
//                    "document.querySelector('#identificationExpireDate > nz-picker > span > input').value = arguments[0];", idExpire);
        }
    }

    public void setIdFrontIMG(String idfrontpath){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("function getElementByXpath (path) {\n" +
                    "   document.evaluate(path, document, null,\n" +
                    "    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.display = 'block';\n" +
                    "}", idImgFrontXpath);
            driver.findElement(idFrontIMG).sendKeys(idfrontpath);
            js.executeScript("function getElementByXpath (path) {\n" +
                    "   document.evaluate(path, document, null,\n" +
                    "    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.display = 'none';\n" +
                    "}", idImgFrontXpath);

            //WebElement webElement = commonOpObj.waitUntilElementClickable(idFrontIMG, Constants.EXPLICIT_TIMEOUT);
            //webElement.sendKeys(idfrontpath);
        }
    }

    public void setIdBackIMG(String idbackpath){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("function getElementByXpath (path) {\n" +
                    "   document.evaluate(path, document, null,\n" +
                    "    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.display = 'block';\n" +
                    "}", idImgBackXpath);
            driver.findElement(idBackIMG).sendKeys(idbackpath);
            js.executeScript("function getElementByXpath (path) {\n" +
                    "   document.evaluate(path, document, null,\n" +
                    "    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.display = 'none';\n" +
                    "}", idImgBackXpath);
        }
    }

    public void setIdSecondaryIF(String secIdtype){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(idSecondaryIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
            webElement.sendKeys(secIdtype);
            commonOpObj.Sleep(Constants.TIMEOUT_FOR_DROP_DOWNS);
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public void clickOnSecIDtype(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(idSecondaryIF, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public List<String> getSecIDtypes(){
        List<String> secIDtypes = new LinkedList<>();
        List<WebElement> webelements = driver.findElements(selectOptionsComboBox);
        for(WebElement ele : webelements){
            secIDtypes.add(ele.getText());
        }
        return secIDtypes;
    }

    public void setIdSecondaryIMG(String idSecPath){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("function getElementByXpath (path) {\n" +
                    "   document.evaluate(path, document, null,\n" +
                    "    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.display = 'block';\n" +
                    "}", idImgSecXpath);
            driver.findElement(idSecondaryIMG).sendKeys(idSecPath);
            js.executeScript("function getElementByXpath (path) {\n" +
                    "   document.evaluate(path, document, null,\n" +
                    "    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.display = 'none';\n" +
                    "}", idImgSecXpath);
        }
    }

    public void clickOnContinueBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(continueBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void clickOnCancelBtn(){
        if(commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)){
            WebElement webElement = commonOpObj.waitUntilElementClickable(cancelBtn, Constants.EXPLICIT_TIMEOUT);
            webElement.click();
        }
    }

    public void fillSignUp2PFwithValues(String dob, String place, String idtype, String idno, String idexpire,
                                        String forntpth, String backpath, String secType, String secpath){

        setDateOfBirthIF(dob);
        setPlaceOfBirthIF(place);
        setiDtypeIF(idtype);
        setIdentificationNumberIF(idno);
        setIdExpiryDateIF(idexpire);
        setIdFrontIMG(forntpth);
        setIdBackIMG(backpath);
        setIdSecondaryIF(secType);
        setIdSecondaryIMG(secpath);
        //clickOnContinueBtn();
    }
}
