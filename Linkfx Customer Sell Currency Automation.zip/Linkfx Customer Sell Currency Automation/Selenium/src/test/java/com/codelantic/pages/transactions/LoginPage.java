package com.codelantic.pages.transactions;

import com.codelantic.utilities.CommonOp;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class LoginPage {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public LoginPage(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj =  commonOpObj;
    }

    private By userNameInputField = By.id("username");
    private By passwordInputField = By.id("password");
    private By logInBtn = By.xpath("//span[contains(text(), \"Log In\")]//parent::button");

    public void setUserNameInputField(String username){
        driver.findElement(userNameInputField).sendKeys(username);
    }

    public void setPasswordInputField(String password){
        driver.findElement(passwordInputField).sendKeys(password);
    }

    public void clickOnLogInBtn(){
        driver.findElement(logInBtn).click();
    }

    public void logInToSAPortal( String username, String password){
        setUserNameInputField(username);
        setPasswordInputField(password);
        clickOnLogInBtn();
    }

}
