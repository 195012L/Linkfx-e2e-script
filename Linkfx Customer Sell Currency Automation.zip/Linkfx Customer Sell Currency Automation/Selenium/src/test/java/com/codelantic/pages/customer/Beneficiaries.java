package com.codelantic.pages.customer;

import com.codelantic.utilities.CommonOp;
import com.codelantic.utilities.Constants;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Beneficiaries {

    private RemoteWebDriver driver;
    private CommonOp commonOpObj;

    public Beneficiaries(RemoteWebDriver driver, CommonOp commonOpObj) {
        this.driver = driver;
        this.commonOpObj = commonOpObj;
    }

    private By Row1Name = By.xpath("//table/tbody/tr[1]/td[1]");
    private By Row1Address = By.xpath("//table/tbody/tr[1]/td[2]");
    private By Row1ContactNumber = By.xpath("//table/tbody/tr[1]/td[3]");
    private By Row1ViewBtn = By.xpath("//table/tbody/tr[1]/td[5]");
    private By loader = By.cssSelector(".loader");
    private By profileBtn = By.cssSelector(".profile-btn");
    private By tableName = By.xpath("//h4[contains(text(), \"Beneficiary List\")]");
    private By filterByValueName = By.xpath("//span[contains(text(),\"Name\")]/ancestor::button");
    private By filterByValueCOntactNo = By.xpath("//span[contains(text(),\"Contact Number\")]/ancestor::button");
    private By filterSaveBtn = By.xpath("//span[contains(text(),\"Save\")]/ancestor::button");
    private By filterResetBtn = By.xpath("//span[contains(text(),\"Reset\")]/ancestor::button");
    private By filterByValueNameIF = By.xpath("//input[@placeholder=\"Enter Name\"]");
    private By filterByValueContactNoIF = By.xpath("//input[@placeholder=\"Enter Contact Number\"]");


    public String getRow1Name(){
        return driver.findElement(Row1Name).getText();
    }

    public String getRow1Address(){
        return driver.findElement(Row1Address).getText();
    }

    public String getRow1ContactNumber(){
        return driver.findElement(Row1ContactNumber).getText();
    }

    public void clickOnRow1ViewBtn() {
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            commonOpObj.waitUntilElementClickable(Row1ViewBtn, Constants.EXPLICIT_TIMEOUT).click();
        }
    }

    public void waituntilBeniTableNameDisplayed(){
        if (commonOpObj.waitUntilElementInvisibilityOf(loader, Constants.EXPLICIT_TIMEOUT)) {
            commonOpObj.waitUntilElementvisibilityOf(tableName, Constants.EXPLICIT_TIMEOUT);
        }
    }

    public void setFilterByValueName(String name){
        resetFilterByValueName();
        commonOpObj.waitUntilElementClickable(filterByValueName, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementClickable(filterByValueNameIF, Constants.EXPLICIT_TIMEOUT).sendKeys(name);
        commonOpObj.waitUntilElementClickable(filterSaveBtn, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementInvisibilityOfElementLocated(loader, Constants.EXPLICIT_TIMEOUT);

    }

    public void resetFilterByValueName(){
        commonOpObj.waitUntilElementClickable(filterByValueName, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementClickable(filterResetBtn, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementInvisibilityOfElementLocated(loader, Constants.EXPLICIT_TIMEOUT);
    }

    public void setFilterByValueCOntactNo(String contactNo){
        resetFilterByValueContactNo();
        commonOpObj.waitUntilElementClickable(filterByValueCOntactNo, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementClickable(filterByValueContactNoIF, Constants.EXPLICIT_TIMEOUT).sendKeys(contactNo);
        commonOpObj.waitUntilElementClickable(filterSaveBtn, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementInvisibilityOfElementLocated(loader, Constants.EXPLICIT_TIMEOUT);
    }

    public void resetFilterByValueContactNo(){
        commonOpObj.waitUntilElementClickable(filterByValueCOntactNo, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementClickable(filterResetBtn, Constants.EXPLICIT_TIMEOUT).click();
        commonOpObj.waitUntilElementInvisibilityOfElementLocated(loader, Constants.EXPLICIT_TIMEOUT);
    }

}
